//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3.ring;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import me.fung.autop3.ConfigGui;
import me.fung.autop3.Preset;
import me.fung.autop3.ring.types.CommandRing;
import me.fung.autop3.ring.types.HClipRing;
import me.fung.autop3.ring.types.JumpRing;
import me.fung.autop3.ring.types.LaunchRing;
import me.fung.autop3.ring.types.LavaClipRing;
import me.fung.autop3.ring.types.MotionRing;
import me.fung.autop3.ring.types.RotateRing;
import me.fung.autop3.ring.types.StopRing;
import me.fung.autop3.ring.types.TntRing;
import me.fung.autop3.ring.types.WalkRing;
import me.fung.autop3.utils.Config;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.util.BlockPos;

public class RingType {
    public static int lastSavedType = -1;
    public static HashMap<Preset, ArrayList<RingType>> rings = new HashMap();
    public double x;
    public double y;
    public double z;
    public double width;
    public double height;
    public boolean awaitTerm;

    public RingType() {
    }

    public static ArrayList<RingType> getCurrentPresetRings() {
        return getPresetRings(Preset.getCurrentPreset());
    }

    public static ArrayList<RingType> getPresetRings(Preset preset) {
        if (!rings.containsKey(preset)) {
            ArrayList<RingType> array = new ArrayList();
            rings.put(preset, array);
            return array;
        } else {
            return (ArrayList)rings.get(preset);
        }
    }

    public RingType(double x, double y, double z, double width, double height) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.width = width;
        this.height = height;
    }

    public static void save() {
        Config config = new Config("rings.json");

        for(Preset preset : Preset.values()) {
            JsonArray ringArray = new JsonArray();

            for(RingType ring : getPresetRings(preset)) {
                JsonObject ringJson = new JsonObject();
                if (ring instanceof MotionRing) {
                    ringJson.addProperty("type", "motion");
                    ringJson.addProperty("yaw", ((MotionRing)ring).yaw);
                } else if (ring instanceof StopRing) {
                    ringJson.addProperty("type", "stop");
                } else if (ring instanceof HClipRing) {
                    ringJson.addProperty("type", "hclip");
                    ringJson.addProperty("yaw", ((HClipRing)ring).yaw);
                } else if (ring instanceof WalkRing) {
                    ringJson.addProperty("type", "walk");
                    ringJson.addProperty("yaw", ((WalkRing)ring).yaw);
                } else if (ring instanceof RotateRing) {
                    RotateRing rotateRing = (RotateRing)ring;
                    ringJson.addProperty("type", "rotate");
                    ringJson.addProperty("yaw", rotateRing.yaw);
                    ringJson.addProperty("pitch", rotateRing.pitch);
                } else if (ring instanceof TntRing) {
                    BlockPos pos = ((TntRing)ring).pos;
                    ringJson.addProperty("type", "tnt");
                    ringJson.addProperty("posX", pos.func_177958_n());
                    ringJson.addProperty("posY", pos.func_177956_o());
                    ringJson.addProperty("posZ", pos.func_177952_p());
                } else if (ring instanceof JumpRing) {
                    ringJson.addProperty("type", "jump");
                } else if (ring instanceof LaunchRing) {
                    ringJson.addProperty("type", "launch");
                    ringJson.addProperty("motionY", ((LaunchRing)ring).motionY);
                } else if (ring instanceof CommandRing) {
                    ringJson.addProperty("type", "command");
                    ringJson.addProperty("command", ((CommandRing)ring).command);
                } else if (ring instanceof LavaClipRing) {
                    ringJson.addProperty("type", "clip");
                    ringJson.addProperty("block", ((LavaClipRing)ring).factor);
                }

                ringJson.addProperty("x", ring.x);
                ringJson.addProperty("y", ring.y);
                ringJson.addProperty("z", ring.z);
                ringJson.addProperty("width", ring.width);
                ringJson.addProperty("height", ring.height);
                if (ring.awaitTerm) {
                    ringJson.addProperty("awaitTerm", true);
                }

                ringArray.add(ringJson);
            }

            config.data.add(preset.presetName, ringArray);
        }

        config.save();
    }

    public static void load() {
        RingType.rings.clear();
        Config config = new Config("rings.json");

        for(Preset preset : Preset.values()) {
            if (config.data.has(preset.presetName)) {
                for(JsonElement element : config.data.getAsJsonArray(preset.presetName)) {
                    try {
                        JsonObject ringJson = element.getAsJsonObject();
                        RingType ring;
                        switch (ringJson.get("type").getAsString()) {
                            case "motion":
                                ring = new MotionRing(ringJson.get("yaw").getAsDouble());
                                break;
                            case "stop":
                                ring = new StopRing();
                                break;
                            case "hclip":
                                ring = new HClipRing(ringJson.get("yaw").getAsDouble());
                                break;
                            case "walk":
                                ring = new WalkRing(ringJson.get("yaw").getAsDouble());
                                break;
                            case "rotate":
                                ring = new RotateRing(ringJson.get("yaw").getAsDouble(), ringJson.get("pitch").getAsDouble());
                                break;
                            case "tnt":
                                ring = new TntRing(new BlockPos(ringJson.get("posX").getAsInt(), ringJson.get("posY").getAsInt(), ringJson.get("posZ").getAsInt()));
                                break;
                            case "jump":
                                ring = new JumpRing();
                                break;
                            case "launch":
                                ring = new LaunchRing(ringJson.get("motionY").getAsDouble());
                                break;
                            case "command":
                                ring = new CommandRing(ringJson.get("command").getAsString());
                                break;
                            case "clip":
                                ring = new LavaClipRing(ringJson.get("block").getAsDouble());
                                break;
                            default:
                                continue;
                        }

                        ring.x = ringJson.get("x").getAsDouble();
                        ring.y = ringJson.get("y").getAsDouble();
                        ring.z = ringJson.get("z").getAsDouble();
                        ring.width = ringJson.get("width").getAsDouble();
                        ring.height = ringJson.get("height").getAsDouble();
                        ring.awaitTerm = ringJson.has("awaitTerm");
                        getPresetRings(preset).add(ring);
                    } catch (Exception var13) {
                    }
                }
            }
        }

    }

    public static RingType getRingAtCursor() {
        EntityPlayerSP player = Minecraft.func_71410_x().field_71439_g;
        double radians = Math.toRadians((double)player.field_70177_z);
        double radians2 = Math.toRadians((double)player.field_70125_A);
        double startX = player.field_70165_t;
        double startY = player.field_70163_u + (double)player.func_70047_e();
        double startZ = player.field_70161_v;
        double endX = startX + -Math.sin(radians) * (double)ConfigGui.INSTANCE.selectorRange * Math.cos(radians2) - startX;
        double endY = startY + (double)ConfigGui.INSTANCE.selectorRange * -Math.sin(radians2) - startY;
        double endZ = startZ + Math.cos(radians) * (double)ConfigGui.INSTANCE.selectorRange * Math.cos(radians2) - startZ;
        RingType nearestRing = null;
        double nearestDistance = Double.MAX_VALUE;

        for(RingType ring : getCurrentPresetRings()) {
            double distanceSQ = Math.pow(startX - ring.x, (double)2.0F) * Math.pow(startY - ring.y, (double)2.0F) * Math.pow(startZ - ring.z, (double)2.0F);
            if (!(distanceSQ > Math.pow((double)ConfigGui.INSTANCE.selectorRange, (double)2.0F))) {
                double radius = ring.width / (double)2.0F;
                double minX = ring.x - radius;
                double minY = ring.y;
                double minZ = ring.z - radius;
                double maxX = ring.x + radius;
                double maxY = ring.y + ring.height;
                double maxZ = ring.z + radius;
                double tMin = (minX - startX) / endX;
                double tMax = (maxX - startX) / endX;
                if (tMin > tMax) {
                    double temp = tMin;
                    tMin = tMax;
                    tMax = temp;
                }

                double tyMin = (minY - startY) / endY;
                double tyMax = (maxY - startY) / endY;
                if (tyMin > tyMax) {
                    double temp = tyMin;
                    tyMin = tyMax;
                    tyMax = temp;
                }

                if (!(tMin > tyMax) && !(tyMin > tMax)) {
                    if (tyMin > tMin) {
                        tMin = tyMin;
                    }

                    if (tyMax < tMax) {
                        tMax = tyMax;
                    }

                    double tzMin = (minZ - startZ) / endZ;
                    double tzMax = (maxZ - startZ) / endZ;
                    if (tzMin > tzMax) {
                        double temp = tzMin;
                        tzMin = tzMax;
                        tzMax = temp;
                    }

                    if (tMin <= tzMax && tzMin <= tMax && distanceSQ < nearestDistance) {
                        nearestRing = ring;
                    }
                }
            }
        }

        return nearestRing;
    }

    public boolean run() {
        return true;
    }

    public Color getRingColor() {
        return Color.WHITE;
    }
}
