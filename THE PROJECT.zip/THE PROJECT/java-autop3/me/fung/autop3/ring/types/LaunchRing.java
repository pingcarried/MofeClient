//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3.ring.types;

import java.awt.Color;
import me.fung.autop3.ConfigGui;
import me.fung.autop3.features.AutoP3Handler;
import me.fung.autop3.ring.RingType;
import me.fung.autop3.utils.Utils;

public class LaunchRing extends RingType {
    public double motionY;

    public LaunchRing(double motionY) {
        this.motionY = motionY;
    }

    public boolean run() {
        AutoP3Handler.nextLaunchY = this.motionY;
        Utils.addChatMessage("Modifying next launch");
        return true;
    }

    public Color getRingColor() {
        return ConfigGui.INSTANCE.launchRingColor;
    }
}
