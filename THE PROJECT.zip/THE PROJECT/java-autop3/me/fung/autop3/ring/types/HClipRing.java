//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3.ring.types;

import java.awt.Color;
import me.fung.autop3.ConfigGui;
import me.fung.autop3.features.MotionHandler;
import me.fung.autop3.ring.RingType;
import me.fung.autop3.utils.PlayerUtils;
import me.fung.autop3.utils.Utils;
import net.minecraft.client.Minecraft;

public class HClipRing extends RingType {
    public double yaw;

    public HClipRing(double yaw) {
        this.yaw = yaw;
    }

    public boolean run() {
        Utils.addChatMessage("HClip");
        Minecraft mc = Minecraft.func_71410_x();
        PlayerUtils.MOVEMENT_KEYS.forEach((key) -> Utils.setKeyBindState(key, false));
        mc.field_71439_g.func_70016_h((double)0.0F, mc.field_71439_g.field_70181_x, (double)0.0F);
        Utils.scheduleTask(0, () -> {
            MotionHandler.INSTANCE.motioning = false;
            double speed = (double)mc.field_71439_g.field_71075_bZ.func_75094_b() * 2.8;
            double radians = this.yaw * Math.PI / (double)180.0F;
            double x = -Math.sin(radians) * speed;
            double z = Math.cos(radians) * speed;
            mc.field_71439_g.func_70016_h(x, mc.field_71439_g.field_70181_x, z);
        }, true);
        return true;
    }

    public Color getRingColor() {
        return ConfigGui.INSTANCE.hclipRingColor;
    }
}
