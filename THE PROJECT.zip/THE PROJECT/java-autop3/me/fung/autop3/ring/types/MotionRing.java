//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3.ring.types;

import java.awt.Color;
import me.fung.autop3.ConfigGui;
import me.fung.autop3.features.MotionHandler;
import me.fung.autop3.ring.RingType;

public class MotionRing extends RingType {
    public double yaw;

    public MotionRing(double yaw) {
        this.yaw = yaw;
    }

    public boolean run() {
        return MotionHandler.motion(this.yaw);
    }

    public Color getRingColor() {
        return ConfigGui.INSTANCE.motionRingColor;
    }
}
