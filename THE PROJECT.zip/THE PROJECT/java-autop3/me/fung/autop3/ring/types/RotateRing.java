//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3.ring.types;

import java.awt.Color;
import me.fung.autop3.ConfigGui;
import me.fung.autop3.ring.RingType;
import me.fung.autop3.utils.Utils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;

public class RotateRing extends RingType {
    public double yaw;
    public double pitch;

    public RotateRing(double yaw, double pitch) {
        this.yaw = yaw;
        this.pitch = pitch;
    }

    public boolean run() {
        Utils.addChatMessage("Rotate!");
        EntityPlayerSP player = Minecraft.func_71410_x().field_71439_g;
        player.field_70177_z = (float)this.yaw;
        player.field_70125_A = (float)this.pitch;
        return true;
    }

    public Color getRingColor() {
        return ConfigGui.INSTANCE.rotateRingColor;
    }
}
