//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3.ring.types;

import java.awt.Color;
import me.fung.autop3.ConfigGui;
import me.fung.autop3.ring.RingType;
import me.fung.autop3.utils.Utils;

public class CommandRing extends RingType {
    public String command;

    public CommandRing(String command) {
        this.command = command;
    }

    public boolean run() {
        Utils.sendMessage(this.command);
        return true;
    }

    public Color getRingColor() {
        return ConfigGui.INSTANCE.commandRingColor;
    }
}
