//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3.ring.types;

import java.awt.Color;
import me.fung.autop3.ConfigGui;
import me.fung.autop3.ring.RingType;
import me.fung.autop3.utils.Utils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;

public class JumpRing extends RingType {
    public boolean run() {
        EntityPlayerSP player = Minecraft.func_71410_x().field_71439_g;
        if (player.field_70122_E) {
            Utils.addChatMessage("Jump!");
            player.func_70664_aZ();
            return true;
        } else {
            return false;
        }
    }

    public Color getRingColor() {
        return ConfigGui.INSTANCE.jumpRingColor;
    }
}
