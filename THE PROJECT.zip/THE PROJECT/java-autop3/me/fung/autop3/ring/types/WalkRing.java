//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3.ring.types;

import java.awt.Color;
import me.fung.autop3.ConfigGui;
import me.fung.autop3.features.MotionHandler;
import me.fung.autop3.ring.RingType;
import me.fung.autop3.utils.Utils;

public class WalkRing extends RingType {
    public double yaw;

    public WalkRing(double yaw) {
        this.yaw = yaw;
    }

    public boolean run() {
        Utils.addChatMessage("Walk!");
        MotionHandler.walk(this.yaw);
        return true;
    }

    public Color getRingColor() {
        return ConfigGui.INSTANCE.walkRingColor;
    }
}
