//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3.ring.types;

import java.awt.Color;
import me.fung.autop3.ConfigGui;
import me.fung.autop3.features.MotionHandler;
import me.fung.autop3.ring.RingType;
import me.fung.autop3.utils.PlayerUtils;
import me.fung.autop3.utils.Utils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;

public class StopRing extends RingType {
    public boolean run() {
        Utils.addChatMessage("Stop!");
        PlayerUtils.MOVEMENT_KEYS.forEach((key) -> Utils.setKeyBindState(key, false));
        EntityPlayerSP player = Minecraft.func_71410_x().field_71439_g;
        player.field_70159_w = (double)0.0F;
        player.field_70179_y = (double)0.0F;
        MotionHandler.INSTANCE.motioning = false;
        return true;
    }

    public Color getRingColor() {
        return ConfigGui.INSTANCE.stopRingColor;
    }
}
