//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3.ring.types;

import java.awt.Color;
import me.fung.autop3.ConfigGui;
import me.fung.autop3.features.LavaClipHandler;
import me.fung.autop3.ring.RingType;
import me.fung.autop3.utils.Utils;

public class LavaClipRing extends RingType {
    public double factor;

    public LavaClipRing(double factor) {
        this.factor = factor;
    }

    public boolean run() {
        Utils.addChatMessage("Clipping " + this.factor);
        LavaClipHandler.clip(this.factor);
        return true;
    }

    public Color getRingColor() {
        return ConfigGui.INSTANCE.lavaClipRingColor;
    }
}
