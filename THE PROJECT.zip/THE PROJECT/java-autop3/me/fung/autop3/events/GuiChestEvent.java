//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3.events;

import java.util.List;
import net.minecraft.client.gui.inventory.GuiChest;
import net.minecraft.inventory.Slot;
import net.minecraftforge.fml.common.eventhandler.Event;

public class GuiChestEvent extends Event {
    public final String title;
    public final List<Slot> slots;
    public final int mouseX;
    public final int mouseY;
    public GuiChest chest;

    public GuiChestEvent(GuiChest chest, String title, List<Slot> slots, int mouseX, int mouseY) {
        this.chest = chest;
        this.title = title;
        this.slots = slots;
        this.mouseX = mouseX;
        this.mouseY = mouseY;
    }
}
