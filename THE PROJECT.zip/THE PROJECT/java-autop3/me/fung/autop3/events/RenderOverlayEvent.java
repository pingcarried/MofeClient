//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3.events;

import net.minecraftforge.fml.common.eventhandler.Event;

public class RenderOverlayEvent extends Event {
}
