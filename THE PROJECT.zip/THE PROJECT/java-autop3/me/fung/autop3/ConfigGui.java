//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3;

import gg.essential.vigilance.Vigilant;
import gg.essential.vigilance.data.Property;
import gg.essential.vigilance.data.PropertyType;
import java.awt.Color;
import java.io.File;
import net.minecraft.client.Minecraft;

public class ConfigGui extends Vigilant {
    public static final ConfigGui INSTANCE = new ConfigGui();
    @Property(
            name = "Toggle Sprint",
            description = "Makes you keep sprinting",
            category = "Feature",
            subcategory = "General",
            type = PropertyType.SWITCH
    )
    public boolean toggleSprint;
    @Property(
            name = "F3 + N",
            description = "nigger.",
            category = "Feature",
            subcategory = "General",
            type = PropertyType.SWITCH
    )
    public boolean gameModeSwitch = true;
    @Property(
            name = "Lava Simulator",
            description = "",
            category = "Feature",
            subcategory = "General",
            type = PropertyType.SWITCH
    )
    public boolean lavaSimulator = true;
    @Property(
            name = "Mod Prefix",
            description = "",
            category = "Feature",
            subcategory = "General",
            type = PropertyType.TEXT
    )
    public String prefix = "§8[§bAuto P3§8] §f";
    @Property(
            name = "Trailer",
            description = "Draw a trail that shows your walking path",
            category = "Feature",
            subcategory = "Trailer",
            type = PropertyType.SWITCH
    )
    public boolean trailer = false;
    @Property(
            name = "Trailer Length",
            description = "Set your trailers' length",
            category = "Feature",
            subcategory = "Trailer",
            type = PropertyType.SLIDER,
            min = 1,
            max = 20
    )
    public int trailerLength = 1;
    @Property(
            name = "Crypt Ghoul Aura",
            description = "Kill Aura for Crypt Ghouls",
            category = "Feature",
            subcategory = "Miscellaneous",
            type = PropertyType.SWITCH
    )
    public boolean cryptGhoulAura;
    @Property(
            name = "Toggle Auto P3",
            description = "",
            category = "Auto P3",
            subcategory = "General",
            type = PropertyType.SWITCH
    )
    public boolean autoP3Toggle = true;
    @Property(
            name = "P3 Only",
            description = "Only activate in phase 3",
            category = "Auto P3",
            subcategory = "General",
            type = PropertyType.SWITCH
    )
    public boolean onlyActivateInP3 = true;
    @Property(
            name = "Config Preset",
            description = "",
            category = "Auto P3",
            subcategory = "General",
            type = PropertyType.SELECTOR,
            options = {"Default", "Archer", "Berserk", "Healer", "Mage", "Tank"}
    )
    public int configMode;
    @Property(
            name = "Motion Strength",
            description = "Adjust how long you can dash (Default: 6)",
            category = "Auto P3",
            subcategory = "General",
            type = PropertyType.DECIMAL_SLIDER,
            minF = 1.0F,
            maxF = 10.0F
    )
    public float motionStrength = 6.0F;
    @Property(
            name = "Second Tick Multiplier",
            description = "Default: 0.7",
            category = "Auto P3",
            subcategory = "General",
            type = PropertyType.DECIMAL_SLIDER,
            maxF = 1.0F
    )
    public float secondTickMultiplier = 0.7F;
    @Property(
            name = "Motion Cooldown",
            description = "ms",
            category = "Auto P3",
            subcategory = "General",
            type = PropertyType.SLIDER,
            max = 1000
    )
    public int motionOnGroundCD = 200;
    @Property(
            name = "Selector Range",
            description = "",
            category = "Auto P3",
            subcategory = "General",
            type = PropertyType.SLIDER,
            max = 50
    )
    public int selectorRange = 10;
    @Property(
            name = "Hide Deactivate Rings",
            description = "",
            category = "Auto P3",
            subcategory = "General",
            type = PropertyType.SWITCH
    )
    public boolean hideDeactivateRings = true;
    @Property(
            name = "Ring Display Type",
            description = "",
            category = "Auto P3",
            subcategory = "General",
            type = PropertyType.SELECTOR,
            options = {"Ring", "Box"}
    )
    public int displayMode;
    @Property(
            name = "See through wall",
            description = "Ring see through wall",
            category = "Auto P3",
            subcategory = "General",
            type = PropertyType.SWITCH
    )
    public boolean seeThroughWall = true;
    @Property(
            name = "HClip Ring Color",
            description = "Color for HClip Rings",
            category = "Auto P3",
            subcategory = "Ring's Color",
            type = PropertyType.COLOR
    )
    public Color hclipRingColor;
    @Property(
            name = "Walk Ring Color",
            description = "Color for Walk Rings",
            category = "Auto P3",
            subcategory = "Ring's Color",
            type = PropertyType.COLOR
    )
    public Color walkRingColor;
    @Property(
            name = "Motion Ring Color",
            description = "Color for Motion Rings",
            category = "Auto P3",
            subcategory = "Ring's Color",
            type = PropertyType.COLOR
    )
    public Color motionRingColor;
    @Property(
            name = "Stop Ring Color",
            description = "Color for Stop Motion Rings",
            category = "Auto P3",
            subcategory = "Ring's Color",
            type = PropertyType.COLOR
    )
    public Color stopRingColor;
    @Property(
            name = "Rotate Ring Color",
            description = "Color for Rotate Rings",
            category = "Auto P3",
            subcategory = "Ring's Color",
            type = PropertyType.COLOR
    )
    public Color rotateRingColor;
    @Property(
            name = "TNT Ring Color",
            description = "Color for TNT Rings",
            category = "Auto P3",
            subcategory = "Ring's Color",
            type = PropertyType.COLOR
    )
    public Color tntRingColor;
    @Property(
            name = "Jump Ring Color",
            description = "Color for Jump Rings",
            category = "Auto P3",
            subcategory = "Ring's Color",
            type = PropertyType.COLOR
    )
    public Color jumpRingColor;
    @Property(
            name = "Launch Ring Color",
            description = "Color for Launch Rings",
            category = "Auto P3",
            subcategory = "Ring's Color",
            type = PropertyType.COLOR
    )
    public Color launchRingColor;
    @Property(
            name = "Command Ring Color",
            description = "Color for Command Motion Rings",
            category = "Auto P3",
            subcategory = "Ring's Color",
            type = PropertyType.COLOR
    )
    public Color commandRingColor;
    @Property(
            name = "Lava Clip Ring Color",
            description = "Color for Stop Motion Rings",
            category = "Auto P3",
            subcategory = "Ring's Color",
            type = PropertyType.COLOR
    )
    public Color lavaClipRingColor;
    @Property(
            name = "Show Selecting Ring",
            description = "Show the ring at your cursor you are trying to edit",
            category = "Auto P3",
            subcategory = "Debug",
            type = PropertyType.SWITCH
    )
    public boolean showSelectingRing;
    @Property(
            name = "Stop Ring Color",
            description = "Color for Stop Motion Rings",
            category = "Auto P3",
            subcategory = "Debug",
            type = PropertyType.COLOR
    )
    public Color selectingRingColor;

    public ConfigGui() {
        super(new File(Minecraft.func_71410_x().field_71412_D + "/config/kaze/autop3.toml"), "Kaze's Auto P3");
        this.hclipRingColor = Color.BLUE;
        this.walkRingColor = Color.YELLOW;
        this.motionRingColor = Color.GREEN;
        this.stopRingColor = Color.RED;
        this.rotateRingColor = Color.MAGENTA;
        this.tntRingColor = Color.ORANGE;
        this.jumpRingColor = Color.WHITE;
        this.launchRingColor = Color.PINK;
        this.commandRingColor = Color.DARK_GRAY;
        this.lavaClipRingColor = new Color(155, 0, 0);
        this.showSelectingRing = false;
        this.selectingRingColor = Color.WHITE;
        this.addDependency("trailerLength", "trailer");
        this.addDependency("selectingRingColor", "showSelectingRing");
        this.initialize();
    }
}
