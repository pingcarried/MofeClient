//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import me.fung.autop3.Main;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C16PacketClientStatus;
import net.minecraft.network.play.client.C16PacketClientStatus.EnumState;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.StringUtils;
import net.minecraft.util.Vec3;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;
import net.minecraftforge.fml.relauncher.ReflectionHelper;

public class PlayerUtils {
    public static final List<KeyBinding> MOVEMENT_KEYS;
    public static ArrayList<PlaceQueue> useQueue;

    public static void placeQueue(String itemName, BlockPos pos, boolean rightClick) {
        int slot = getItemInHotbar(itemName);
        if (slot == -1) {
            Utils.addChatMessage("Couldn't find " + itemName + " in your hotbar!");
        } else {
            useQueue.add(new PlaceQueue(slot, pos, rightClick));
        }
    }

    public static Vec3 getVectorForRotation(float yaw, float pitch) {
        float f = MathHelper.func_76134_b(-pitch * ((float)Math.PI / 180F) - (float)Math.PI);
        float f1 = MathHelper.func_76126_a(-pitch * ((float)Math.PI / 180F) - (float)Math.PI);
        float f2 = -MathHelper.func_76134_b(-yaw * ((float)Math.PI / 180F));
        float f3 = MathHelper.func_76126_a(-yaw * ((float)Math.PI / 180F));
        return new Vec3((double)(f1 * f2), (double)f3, (double)(f * f2));
    }

    public static boolean betterClickEntity(Entity entity) {
        Minecraft mc = Minecraft.func_71410_x();
        List<MovingObjectPosition> c = (List)getRandomSide(entity).stream().filter((mopx) -> mopx.field_72307_f.func_72438_d(mc.field_71439_g.func_174791_d()) < (double)5.0F).collect(Collectors.toList());
        if (c.isEmpty()) {
            return false;
        } else {
            MovingObjectPosition mop = (MovingObjectPosition)c.get(MathUtils.randomNumber(0, c.size() - 1));
            if (!mc.field_71442_b.func_178894_a(mc.field_71439_g, mop.field_72308_g, mop)) {
                mc.field_71442_b.func_78768_b(mc.field_71439_g, mop.field_72308_g);
            }

            return true;
        }
    }

    public static ArrayList<BlockPos> getPosAround(int radius) {
        BlockPos playerPos = getPlayerPos();
        ArrayList<BlockPos> array = new ArrayList();

        for(int x = playerPos.func_177958_n() - radius; x < playerPos.func_177958_n() + radius; ++x) {
            for(int y = playerPos.func_177956_o() - radius; y < playerPos.func_177956_o() + radius; ++y) {
                for(int z = playerPos.func_177952_p() - radius; z < playerPos.func_177952_p() + radius; ++z) {
                    array.add(new BlockPos(x, y, z));
                }
            }
        }

        return array;
    }

    public static int getItemInHotbar(String name) {
        EntityPlayer player = Minecraft.func_71410_x().field_71439_g;
        name = name.toLowerCase();

        for(int i = 0; i < 8; ++i) {
            ItemStack stack = player.field_71071_by.func_70301_a(i);
            if (stack != null && stack.func_82833_r() != null) {
                String n = StringUtils.func_76338_a(stack.func_82833_r()).toLowerCase();
                if (n.toLowerCase().contains(name)) {
                    return i;
                }
            }
        }

        return -1;
    }

    public static int getItemInHotbarBySkyblockId(String skyblockId) {
        EntityPlayer player = Minecraft.func_71410_x().field_71439_g;

        for(int i = 0; i < 8; ++i) {
            String stackId = SkyblockUtils.getSkyBlockItemID(player.field_71071_by.func_70301_a(i));
            if (skyblockId.equals(stackId)) {
                return i;
            }
        }

        return -1;
    }

    public static int getItemInHotbar(Item item) {
        EntityPlayer player = Minecraft.func_71410_x().field_71439_g;

        for(int i = 0; i < 8; ++i) {
            ItemStack stack = player.field_71071_by.func_70301_a(i);
            if (stack != null && stack.func_77973_b() == item) {
                return i;
            }
        }

        return -1;
    }

    public static void useOneOfThose(Item... items) {
    }

    public static BlockPos getPlayerPos() {
        Entity view = Minecraft.func_71410_x().func_175606_aa();
        return new BlockPos(view.field_70165_t, view.func_174813_aQ().field_72338_b, view.field_70161_v);
    }

    public static void openInventory() {
        Main.mc.func_147114_u().func_147297_a(new C16PacketClientStatus(EnumState.OPEN_INVENTORY_ACHIEVEMENT));
        Main.mc.func_147108_a(new GuiInventory(Main.mc.field_71439_g));
    }

    public static int getItemSlotInInventory(String itemName) {
        if (itemName == null) {
            return -1;
        } else {
            for(int i = 9; i < 45; ++i) {
                ItemStack item = Main.mc.field_71439_g.field_71069_bz.func_75139_a(i).func_75211_c();
                if (item != null && item.func_82833_r().contains(itemName)) {
                    return i;
                }
            }

            return -1;
        }
    }

    public static List<ItemStack> getInventoryItems() {
        ArrayList<ItemStack> list = new ArrayList();

        for(int i = 9; i < 45; ++i) {
            ItemStack item = Main.mc.field_71439_g.field_71069_bz.func_75139_a(i).func_75211_c();
            if (item != null) {
                list.add(item);
            }
        }

        return list;
    }

    public static void rightClick() {
        try {
            ReflectionHelper.findMethod(Minecraft.class, Minecraft.func_71410_x(), new String[]{"rightClickMouse", "func_147121_ag"}, new Class[0]).invoke(Minecraft.func_71410_x());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static ArrayList<MovingObjectPosition> getRandomSide(Entity entity) {
        ArrayList<MovingObjectPosition> array = new ArrayList();
        Vec3 vec3 = entity.func_174791_d();
        Vec3 playerVec = Minecraft.func_71410_x().field_71439_g.func_174824_e(1.0F);
        double playerX = playerVec.field_72450_a;
        double playerY = playerVec.field_72448_b;
        double playerZ = playerVec.field_72449_c;
        double x = vec3.field_72450_a;
        double y = vec3.field_72448_b;
        double z = vec3.field_72449_c;
        double minX = entity.func_174813_aQ().field_72340_a;
        double minY = entity.func_174813_aQ().field_72338_b;
        double minZ = entity.func_174813_aQ().field_72339_c;
        double maxX = entity.func_174813_aQ().field_72336_d;
        double maxY = entity.func_174813_aQ().field_72337_e;
        double maxZ = entity.func_174813_aQ().field_72334_f;

        for(int i = 0; i < 10; ++i) {
            if (x >= playerX) {
                array.add(new MovingObjectPosition(entity, new Vec3(minX, MathUtils.randomNumber(minY, maxY), MathUtils.randomNumber(minZ, maxZ))));
            }

            if (x <= playerX) {
                array.add(new MovingObjectPosition(entity, new Vec3(maxX, MathUtils.randomNumber(minY, maxY), MathUtils.randomNumber(minZ, maxZ))));
            }

            if (z <= playerZ) {
                array.add(new MovingObjectPosition(entity, new Vec3(MathUtils.randomNumber(minX, maxX), MathUtils.randomNumber(minY, maxY), maxZ)));
            }

            if (z >= playerZ) {
                array.add(new MovingObjectPosition(entity, new Vec3(MathUtils.randomNumber(minX, maxX), MathUtils.randomNumber(minY, maxY), minZ)));
            }

            if (y <= playerY) {
                array.add(new MovingObjectPosition(entity, new Vec3(MathUtils.randomNumber(minX, maxX), maxY, MathUtils.randomNumber(minZ, maxZ))));
            }

            if (y >= playerY) {
                array.add(new MovingObjectPosition(entity, new Vec3(MathUtils.randomNumber(minX, maxX), minY, MathUtils.randomNumber(minZ, maxZ))));
            }
        }

        return array;
    }

    public static ArrayList<MovingObjectPosition> getRandomSide(BlockPos pos) {
        ArrayList<MovingObjectPosition> array = new ArrayList();
        IBlockState state = Minecraft.func_71410_x().field_71441_e.func_180495_p(pos);
        Block block = state.func_177230_c();
        Vec3 playerVec = Minecraft.func_71410_x().field_71439_g.func_174824_e(1.0F);
        double playerX = playerVec.field_72450_a;
        double playerY = playerVec.field_72448_b;
        double playerZ = playerVec.field_72449_c;
        int x = pos.func_177958_n();
        int y = pos.func_177956_o();
        int z = pos.func_177952_p();
        block.func_180654_a(Minecraft.func_71410_x().field_71441_e, pos);
        double minX = block.func_149704_x();
        double minY = block.func_149665_z();
        double minZ = block.func_149706_B();
        double maxX = block.func_149753_y();
        double maxY = block.func_149669_A();
        double maxZ = block.func_149693_C();

        for(int i = 0; i < 10; ++i) {
            if ((double)x >= playerX) {
                array.add(new MovingObjectPosition(MovingObjectType.BLOCK, new Vec3((double)x + minX, (double)y + MathUtils.randomNumber(minY, maxY), (double)z + MathUtils.randomNumber(minZ, maxZ)), EnumFacing.WEST, pos));
            }

            if ((double)x <= playerX) {
                array.add(new MovingObjectPosition(MovingObjectType.BLOCK, new Vec3((double)x + maxX, (double)y + MathUtils.randomNumber(minY, maxY), (double)z + MathUtils.randomNumber(minZ, maxZ)), EnumFacing.EAST, pos));
            }

            if ((double)z <= playerZ) {
                array.add(new MovingObjectPosition(MovingObjectType.BLOCK, new Vec3((double)x + MathUtils.randomNumber(minX, maxX), (double)y + MathUtils.randomNumber(minY, maxY), (double)z + maxZ), EnumFacing.SOUTH, pos));
            }

            if ((double)z >= playerZ) {
                array.add(new MovingObjectPosition(MovingObjectType.BLOCK, new Vec3((double)x + MathUtils.randomNumber(minX, maxX), (double)y + MathUtils.randomNumber(minY, maxY), (double)z + minZ), EnumFacing.NORTH, pos));
            }

            if ((double)y <= playerY) {
                array.add(new MovingObjectPosition(MovingObjectType.BLOCK, new Vec3((double)x + MathUtils.randomNumber(minX, maxX), (double)y + maxY, (double)z + MathUtils.randomNumber(minZ, maxZ)), EnumFacing.UP, pos));
            }

            if ((double)y >= playerY) {
                array.add(new MovingObjectPosition(MovingObjectType.BLOCK, new Vec3((double)x + MathUtils.randomNumber(minX, maxX), (double)y + minY, (double)z + MathUtils.randomNumber(minZ, maxZ)), EnumFacing.DOWN, pos));
            }
        }

        return array;
    }

    public static boolean rightClickBlock(BlockPos pos, double distance) {
        return rightClickBlock(pos);
    }

    public static boolean rightClickBlock(BlockPos pos) {
        ArrayList<MovingObjectPosition> mops = getRandomSide(pos);
        Minecraft mc = Minecraft.func_71410_x();
        if (mops.isEmpty()) {
            return false;
        } else {
            ArrayList<MovingObjectPosition> c = getRandomSide(pos);
            if (c.isEmpty()) {
                return false;
            } else {
                MovingObjectPosition mop = (MovingObjectPosition)c.get(MathUtils.randomNumber(0, c.size() - 1));
                if (mc.field_71442_b.func_178890_a(mc.field_71439_g, mc.field_71441_e, mc.field_71439_g.func_70694_bm(), pos, mop.field_178784_b, mop.field_72307_f)) {
                    mc.field_71439_g.func_71038_i();
                }

                return true;
            }
        }
    }

    public static ArrayList<MovingObjectPosition> getRandomSide(BlockPos pos, EnumFacing enumFacing) {
        ArrayList<MovingObjectPosition> array = new ArrayList();
        IBlockState state = Minecraft.func_71410_x().field_71441_e.func_180495_p(pos);
        Block block = state.func_177230_c();
        int x = pos.func_177958_n();
        int y = pos.func_177956_o();
        int z = pos.func_177952_p();
        block.func_180654_a(Minecraft.func_71410_x().field_71441_e, pos);
        double minX = block.func_149704_x();
        double minY = block.func_149665_z();
        double minZ = block.func_149706_B();
        double maxX = block.func_149753_y();
        double maxY = block.func_149669_A();
        double maxZ = block.func_149693_C();

        for(int i = 0; i < 10; ++i) {
            if (enumFacing == EnumFacing.WEST) {
                array.add(new MovingObjectPosition(MovingObjectType.BLOCK, new Vec3((double)x + minX, (double)y + MathUtils.randomNumber(minY, maxY), (double)z + MathUtils.randomNumber(minZ, maxZ)), EnumFacing.WEST, pos));
            }

            if (enumFacing == EnumFacing.EAST) {
                array.add(new MovingObjectPosition(MovingObjectType.BLOCK, new Vec3((double)x + maxX, (double)y + MathUtils.randomNumber(minY, maxY), (double)z + MathUtils.randomNumber(minZ, maxZ)), EnumFacing.EAST, pos));
            }

            if (enumFacing == EnumFacing.SOUTH) {
                array.add(new MovingObjectPosition(MovingObjectType.BLOCK, new Vec3((double)x + MathUtils.randomNumber(minX, maxX), (double)y + MathUtils.randomNumber(minY, maxY), (double)z + maxZ), EnumFacing.SOUTH, pos));
            }

            if (enumFacing == EnumFacing.NORTH) {
                array.add(new MovingObjectPosition(MovingObjectType.BLOCK, new Vec3((double)x + MathUtils.randomNumber(minX, maxX), (double)y + MathUtils.randomNumber(minY, maxY), (double)z + minZ), EnumFacing.NORTH, pos));
            }

            if (enumFacing == EnumFacing.UP) {
                array.add(new MovingObjectPosition(MovingObjectType.BLOCK, new Vec3((double)x + MathUtils.randomNumber(minX, maxX), (double)y + maxY, (double)z + MathUtils.randomNumber(minZ, maxZ)), EnumFacing.UP, pos));
            }

            if (enumFacing == EnumFacing.DOWN) {
                array.add(new MovingObjectPosition(MovingObjectType.BLOCK, new Vec3((double)x + MathUtils.randomNumber(minX, maxX), (double)y + minY, (double)z + MathUtils.randomNumber(minZ, maxZ)), EnumFacing.DOWN, pos));
            }
        }

        return array;
    }

    static {
        MOVEMENT_KEYS = Arrays.asList(Minecraft.func_71410_x().field_71474_y.field_74351_w, Minecraft.func_71410_x().field_71474_y.field_74370_x, Minecraft.func_71410_x().field_71474_y.field_74366_z, Minecraft.func_71410_x().field_71474_y.field_74368_y);
        useQueue = new ArrayList();
    }

    public static class PlaceQueue {
        public int slot;
        public BlockPos pos;
        public boolean rightClick;

        public PlaceQueue(int slot, BlockPos pos, boolean rightClick) {
            this.slot = slot;
            this.pos = pos;
            this.rightClick = rightClick;
        }
    }
}
