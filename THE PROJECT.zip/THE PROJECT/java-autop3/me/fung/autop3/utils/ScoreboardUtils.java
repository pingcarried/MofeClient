//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3.utils;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.client.Minecraft;
import net.minecraft.scoreboard.Score;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.util.StringUtils;

public class ScoreboardUtils {
    public static String cleanSB(String scoreboard) {
        char[] nvString = StringUtils.func_76338_a(scoreboard).toCharArray();
        StringBuilder cleaned = new StringBuilder();

        for(char c : nvString) {
            if (c > 20 && c < 127) {
                cleaned.append(c);
            }
        }

        return cleaned.toString();
    }

    public static boolean hasLine(String str) {
        for(String line : getSidebarLines()) {
            if (line.contains(str)) {
                return true;
            }
        }

        return false;
    }

    public static List<String> getSidebarLines() {
        List<String> lines = new ArrayList();
        if (Minecraft.func_71410_x().field_71441_e == null) {
            return lines;
        } else {
            Scoreboard scoreboard = Minecraft.func_71410_x().field_71441_e.func_96441_U();
            if (scoreboard == null) {
                return lines;
            } else {
                ScoreObjective objective = scoreboard.func_96539_a(1);
                if (objective == null) {
                    return lines;
                } else {
                    Collection<Score> scores = scoreboard.func_96534_i(objective);
                    List<Score> list = (List)scores.stream().filter((input) -> input != null && input.func_96653_e() != null && !input.func_96653_e().startsWith("#")).collect(Collectors.toList());
                    Object var8;
                    if (list.size() > 15) {
                        var8 = Lists.newArrayList(Iterables.skip(list, scores.size() - 15));
                    } else {
                        var8 = list;
                    }

                    for(Score score : var8) {
                        ScorePlayerTeam team = scoreboard.func_96509_i(score.func_96653_e());
                        lines.add(ScorePlayerTeam.func_96667_a(team, score.func_96653_e()));
                    }

                    return lines;
                }
            }
        }
    }

    public static List<String> getLines() {
        Scoreboard scoreboard = Minecraft.func_71410_x().field_71439_g.func_96123_co();
        ScoreObjective sidebarObjective = scoreboard.func_96539_a(1);
        List<Score> scores = new ArrayList(scoreboard.func_96534_i(sidebarObjective));
        List<String> lines = new ArrayList();

        for(int i = scores.size() - 1; i >= 0; --i) {
            Score score = (Score)scores.get(i);
            ScorePlayerTeam scoreplayerteam1 = scoreboard.func_96509_i(score.func_96653_e());
            String line = ScorePlayerTeam.func_96667_a(scoreplayerteam1, score.func_96653_e()).replaceAll("[\ud83c\udf6b\ud83d\udca3\ud83c\udf89\ud83c\udf6d\ud83d\udc7d\ud83d\udd2e\ud83d\udc0d\ud83d\udc7e\ud83c\udf20⚽\ud83c\udfc0\ud83d\udc79\ud83c\udf81\ud83c\udf82]", "");
            lines.add(StringUtils.func_76338_a(line));
        }

        return lines;
    }
}
