//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3.utils;

import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.network.Packet;

public class PacketUtils {
    public static ArrayList<Packet<?>> packets = new ArrayList();

    public static void sendPacketWithoutEvent(Packet<?> packet) {
        if (Minecraft.func_71410_x().func_147114_u() != null && Minecraft.func_71410_x().func_147114_u().func_147298_b() != null) {
            packets.add(packet);
            Minecraft.func_71410_x().func_147114_u().func_147298_b().func_179290_a(packet);
        }
    }
}
