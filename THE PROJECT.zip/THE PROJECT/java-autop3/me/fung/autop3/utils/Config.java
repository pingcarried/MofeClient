//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3.utils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import net.minecraft.client.Minecraft;

public class Config {
    private static final File DIRECTORY;
    private final File file;
    public JsonObject data;

    public Config(String fileName) {
        if (!DIRECTORY.isDirectory()) {
            DIRECTORY.mkdirs();
        }

        this.file = new File(DIRECTORY, fileName);
        if (!this.file.exists()) {
            this.save();
        }

        JsonParser jsonParser = new JsonParser();

        try (FileReader reader = new FileReader(this.file)) {
            this.data = jsonParser.parse(reader).getAsJsonObject();
        } catch (Exception var16) {
            this.data = new JsonObject();
        }

    }

    public void save() {
        if (this.data != null) {
            try (PrintWriter out = new PrintWriter(new FileWriter(this.file))) {
                JsonParser parser = new JsonParser();
                Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
                JsonElement el = parser.parse(this.data.toString());
                out.write(gson.toJson(el));
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    static {
        DIRECTORY = new File(Minecraft.func_71410_x().field_71412_D + "/config/AutoP3");
    }
}
