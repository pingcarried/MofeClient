//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3.utils;

import java.awt.Color;
import me.fung.autop3.Main;
import me.fung.autop3.events.RenderOverlayEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Timer;
import net.minecraft.util.Vec3;
import net.minecraftforge.fml.common.ObfuscationReflectionHelper;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.Cylinder;

public class RenderUtils {
    private static final ResourceLocation beaconBeam = new ResourceLocation("textures/entity/beacon_beam.png");
    private static String title;
    private static long untilTitle;

    public static void drawLabel(Vec3 pos, String text, float partialTicks, boolean shadow, float scale) {
        Minecraft mc = Minecraft.func_71410_x();
        double x = pos.field_72450_a - mc.field_71439_g.field_70142_S + (pos.field_72450_a - mc.field_71439_g.field_70165_t - (pos.field_72450_a - mc.field_71439_g.field_70142_S)) * (double)partialTicks;
        double y = pos.field_72448_b - mc.field_71439_g.field_70137_T + (pos.field_72448_b - mc.field_71439_g.field_70163_u - (pos.field_72448_b - mc.field_71439_g.field_70137_T)) * (double)partialTicks;
        double z = pos.field_72449_c - mc.field_71439_g.field_70136_U + (pos.field_72449_c - mc.field_71439_g.field_70161_v - (pos.field_72449_c - mc.field_71439_g.field_70136_U)) * (double)partialTicks;
        double f1 = 0.0266666688;
        int width = mc.field_71466_p.func_78256_a(text) / 2;
        GlStateManager.func_179097_i();
        GlStateManager.func_179094_E();
        GlStateManager.func_179137_b(x, y, z);
        GL11.glNormal3f(0.0F, 1.0F, 0.0F);
        GlStateManager.func_179114_b(-mc.func_175598_ae().field_78735_i, 0.0F, 1.0F, 0.0F);
        GlStateManager.func_179114_b(mc.func_175598_ae().field_78732_j, 1.0F, 0.0F, 0.0F);
        GlStateManager.func_179139_a(-f1, -f1, -f1);
        GlStateManager.func_179152_a(scale, scale, scale);
        GlStateManager.func_179147_l();
        GlStateManager.func_179140_f();
        GlStateManager.func_179120_a(770, 771, 1, 0);
        GlStateManager.func_179098_w();
        mc.field_71466_p.func_175065_a(text, (float)(-width), 0.0F, Color.WHITE.getRGB(), shadow);
        GlStateManager.func_179084_k();
        GlStateManager.func_179121_F();
        GlStateManager.func_179126_j();
    }

    public static void drawLine(Vec3 pos1, Vec3 pos2, Color color, float width, boolean seeThroughWall) {
        Minecraft mc = Minecraft.func_71410_x();
        float partialTick = getPartialTicks();
        double realX = mc.func_175606_aa().field_70142_S + (mc.func_175606_aa().field_70165_t - mc.func_175606_aa().field_70142_S) * (double)partialTick;
        double realY = mc.func_175606_aa().field_70137_T + (mc.func_175606_aa().field_70163_u - mc.func_175606_aa().field_70137_T) * (double)partialTick;
        double realZ = mc.func_175606_aa().field_70136_U + (mc.func_175606_aa().field_70161_v - mc.func_175606_aa().field_70136_U) * (double)partialTick;
        int red = color.getRed();
        int green = color.getGreen();
        int blue = color.getBlue();
        int alpha = color.getAlpha();
        GlStateManager.func_179094_E();
        GlStateManager.func_179137_b(-realX, -realY, -realZ);
        GlStateManager.func_179140_f();
        GlStateManager.func_179090_x();
        GlStateManager.func_179147_l();
        GlStateManager.func_179120_a(770, 771, 1, 0);
        GL11.glLineWidth(width);
        Tessellator tes = Tessellator.func_178181_a();
        WorldRenderer wr = tes.func_178180_c();
        wr.func_181668_a(3, DefaultVertexFormats.field_181706_f);
        wr.func_181662_b(pos1.field_72450_a, pos1.field_72448_b, pos1.field_72449_c).func_181669_b(red, green, blue, alpha).func_181675_d();
        wr.func_181662_b(pos2.field_72450_a, pos2.field_72448_b, pos2.field_72449_c).func_181669_b(red, green, blue, alpha).func_181675_d();
        if (seeThroughWall) {
            GL11.glDisable(2929);
        }

        tes.func_78381_a();
        if (seeThroughWall) {
            GL11.glEnable(2929);
        }

        GlStateManager.func_179084_k();
        GlStateManager.func_179121_F();
        GlStateManager.func_179098_w();
    }

    public static void renderRing(double x, double y, double z, float baseRadius, float topRadius, float height, int slices, int stacks, int rotation1, int rotation2, int rotation3, boolean lineMode, Color color, boolean seeThroughWall) {
        float partialTick = getPartialTicks();
        Minecraft mc = Minecraft.func_71410_x();
        x -= mc.func_175606_aa().field_70142_S + (mc.func_175606_aa().field_70165_t - mc.func_175606_aa().field_70142_S) * (double)partialTick;
        y -= mc.func_175606_aa().field_70137_T + (mc.func_175606_aa().field_70163_u - mc.func_175606_aa().field_70137_T) * (double)partialTick;
        z -= mc.func_175606_aa().field_70136_U + (mc.func_175606_aa().field_70161_v - mc.func_175606_aa().field_70136_U) * (double)partialTick;
        GlStateManager.func_179094_E();
        GL11.glLineWidth(2.0F);
        GlStateManager.func_179129_p();
        GlStateManager.func_179147_l();
        GlStateManager.func_179112_b(770, 771);
        GlStateManager.func_179132_a(false);
        GlStateManager.func_179090_x();
        if (seeThroughWall) {
            GlStateManager.func_179097_i();
        }

        GlStateManager.func_179131_c((float)color.getRed() / 255.0F, (float)color.getGreen() / 255.0F, (float)color.getBlue() / 255.0F, (float)color.getAlpha() / 255.0F);
        GlStateManager.func_179137_b(x, y, z);
        GlStateManager.func_179114_b((float)rotation1, 1.0F, 0.0F, 0.0F);
        GlStateManager.func_179114_b((float)rotation2, 0.0F, 0.0F, 1.0F);
        GlStateManager.func_179114_b((float)rotation3, 0.0F, 1.0F, 0.0F);
        Cylinder lineCylinder = new Cylinder();
        lineCylinder.setDrawStyle(100011);
        Cylinder regCylinder = new Cylinder();
        if (lineMode) {
            lineCylinder.draw(baseRadius, topRadius, height, slices, stacks);
        } else {
            regCylinder.draw(baseRadius, topRadius, height, slices, stacks);
        }

        GlStateManager.func_179089_o();
        GlStateManager.func_179084_k();
        GlStateManager.func_179132_a(true);
        GlStateManager.func_179098_w();
        if (seeThroughWall) {
            GlStateManager.func_179126_j();
        }

        GlStateManager.func_179121_F();
    }

    public static void renderBeaconBeam(BlockPos block, int rgb, float alphaMult, float partialTicks) {
        Entity viewer = Minecraft.func_71410_x().func_175606_aa();
        double viewerX = viewer.field_70142_S + (viewer.field_70165_t - viewer.field_70142_S) * (double)partialTicks;
        double viewerY = viewer.field_70137_T + (viewer.field_70163_u - viewer.field_70137_T) * (double)partialTicks;
        double viewerZ = viewer.field_70136_U + (viewer.field_70161_v - viewer.field_70136_U) * (double)partialTicks;
        double x = (double)block.func_177958_n() - viewerX;
        double y = (double)block.func_177956_o() - viewerY;
        double z = (double)block.func_177952_p() - viewerZ;
        double distSq = x * x + y * y + z * z;
        renderBeaconBeam(x, y, z, rgb, 1.0F, partialTicks, distSq > (double)100.0F);
    }

    private static void renderBeaconBeam(double x, double y, double z, int rgb, float alphaMult, float partialTicks, Boolean disableDepth) {
        int height = 300;
        int bottomOffset = 0;
        int topOffset = bottomOffset + height;
        Tessellator tessellator = Tessellator.func_178181_a();
        WorldRenderer worldrenderer = tessellator.func_178180_c();
        if (disableDepth) {
            GlStateManager.func_179097_i();
        }

        Minecraft.func_71410_x().func_110434_K().func_110577_a(beaconBeam);
        GL11.glTexParameterf(3553, 10242, 10497.0F);
        GL11.glTexParameterf(3553, 10243, 10497.0F);
        GlStateManager.func_179140_f();
        GlStateManager.func_179089_o();
        GlStateManager.func_179098_w();
        GlStateManager.func_179120_a(770, 1, 1, 0);
        GlStateManager.func_179147_l();
        GlStateManager.func_179120_a(770, 771, 1, 0);
        double time = (double)Minecraft.func_71410_x().field_71441_e.func_82737_E() + (double)partialTicks;
        double d1 = MathHelper.func_181162_h(-time * 0.2 - (double)MathHelper.func_76128_c(-time * 0.1));
        float r = (float)(rgb >> 16 & 255) / 255.0F;
        float g = (float)(rgb >> 8 & 255) / 255.0F;
        float b = (float)(rgb & 255) / 255.0F;
        double d2 = time * 0.025 * (double)-1.5F;
        double d4 = (double)0.5F + Math.cos(d2 + 2.356194490192345) * 0.2;
        double d5 = (double)0.5F + Math.sin(d2 + 2.356194490192345) * 0.2;
        double d6 = (double)0.5F + Math.cos(d2 + (Math.PI / 4D)) * 0.2;
        double d7 = (double)0.5F + Math.sin(d2 + (Math.PI / 4D)) * 0.2;
        double d8 = (double)0.5F + Math.cos(d2 + 3.9269908169872414) * 0.2;
        double d9 = (double)0.5F + Math.sin(d2 + 3.9269908169872414) * 0.2;
        double d10 = (double)0.5F + Math.cos(d2 + 5.497787143782138) * 0.2;
        double d11 = (double)0.5F + Math.sin(d2 + 5.497787143782138) * 0.2;
        double d14 = (double)-1.0F + d1;
        double d15 = (double)height * (double)2.5F + d14;
        worldrenderer.func_181668_a(7, DefaultVertexFormats.field_181709_i);
        worldrenderer.func_181662_b(x + d4, y + (double)topOffset, z + d5).func_181673_a((double)1.0F, d15).func_181666_a(r, g, b, alphaMult).func_181675_d();
        worldrenderer.func_181662_b(x + d4, y + (double)bottomOffset, z + d5).func_181673_a((double)1.0F, d14).func_181666_a(r, g, b, 1.0F).func_181675_d();
        worldrenderer.func_181662_b(x + d6, y + (double)bottomOffset, z + d7).func_181673_a((double)0.0F, d14).func_181666_a(r, g, b, 1.0F).func_181675_d();
        worldrenderer.func_181662_b(x + d6, y + (double)topOffset, z + d7).func_181673_a((double)0.0F, d15).func_181666_a(r, g, b, alphaMult).func_181675_d();
        worldrenderer.func_181662_b(x + d10, y + (double)topOffset, z + d11).func_181673_a((double)1.0F, d15).func_181666_a(r, g, b, alphaMult).func_181675_d();
        worldrenderer.func_181662_b(x + d10, y + (double)bottomOffset, z + d11).func_181673_a((double)1.0F, d14).func_181666_a(r, g, b, 1.0F).func_181675_d();
        worldrenderer.func_181662_b(x + d8, y + (double)bottomOffset, z + d9).func_181673_a((double)0.0F, d14).func_181666_a(r, g, b, 1.0F).func_181675_d();
        worldrenderer.func_181662_b(x + d8, y + (double)topOffset, z + d9).func_181673_a((double)0.0F, d15).func_181666_a(r, g, b, alphaMult).func_181675_d();
        worldrenderer.func_181662_b(x + d6, y + (double)topOffset, z + d7).func_181673_a((double)1.0F, d15).func_181666_a(r, g, b, alphaMult).func_181675_d();
        worldrenderer.func_181662_b(x + d6, y + (double)bottomOffset, z + d7).func_181673_a((double)1.0F, d14).func_181666_a(r, g, b, 1.0F).func_181675_d();
        worldrenderer.func_181662_b(x + d10, y + (double)bottomOffset, z + d11).func_181673_a((double)0.0F, d14).func_181666_a(r, g, b, 1.0F).func_181675_d();
        worldrenderer.func_181662_b(x + d10, y + (double)topOffset, z + d11).func_181673_a((double)0.0F, d15).func_181666_a(r, g, b, alphaMult).func_181675_d();
        worldrenderer.func_181662_b(x + d8, y + (double)topOffset, z + d9).func_181673_a((double)1.0F, d15).func_181666_a(r, g, b, alphaMult).func_181675_d();
        worldrenderer.func_181662_b(x + d8, y + (double)bottomOffset, z + d9).func_181673_a((double)1.0F, d14).func_181666_a(r, g, b, 1.0F).func_181675_d();
        worldrenderer.func_181662_b(x + d4, y + (double)bottomOffset, z + d5).func_181673_a((double)0.0F, d14).func_181666_a(r, g, b, 1.0F).func_181675_d();
        worldrenderer.func_181662_b(x + d4, y + (double)topOffset, z + d5).func_181673_a((double)0.0F, d15).func_181666_a(r, g, b, alphaMult).func_181675_d();
        tessellator.func_78381_a();
        GlStateManager.func_179129_p();
        double d12 = (double)-1.0F + d1;
        double d13 = (double)height + d12;
        worldrenderer.func_181668_a(7, DefaultVertexFormats.field_181709_i);
        worldrenderer.func_181662_b(x + 0.2, y + (double)topOffset, z + 0.2).func_181673_a((double)1.0F, d13).func_181666_a(r, g, b, 0.25F * alphaMult).func_181675_d();
        worldrenderer.func_181662_b(x + 0.2, y + (double)bottomOffset, z + 0.2).func_181673_a((double)1.0F, d12).func_181666_a(r, g, b, 0.25F).func_181675_d();
        worldrenderer.func_181662_b(x + 0.8, y + (double)bottomOffset, z + 0.2).func_181673_a((double)0.0F, d12).func_181666_a(r, g, b, 0.25F).func_181675_d();
        worldrenderer.func_181662_b(x + 0.8, y + (double)topOffset, z + 0.2).func_181673_a((double)0.0F, d13).func_181666_a(r, g, b, 0.25F * alphaMult).func_181675_d();
        worldrenderer.func_181662_b(x + 0.8, y + (double)topOffset, z + 0.8).func_181673_a((double)1.0F, d13).func_181666_a(r, g, b, 0.25F * alphaMult).func_181675_d();
        worldrenderer.func_181662_b(x + 0.8, y + (double)bottomOffset, z + 0.8).func_181673_a((double)1.0F, d12).func_181666_a(r, g, b, 0.25F).func_181675_d();
        worldrenderer.func_181662_b(x + 0.2, y + (double)bottomOffset, z + 0.8).func_181673_a((double)0.0F, d12).func_181666_a(r, g, b, 0.25F).func_181675_d();
        worldrenderer.func_181662_b(x + 0.2, y + (double)topOffset, z + 0.8).func_181673_a((double)0.0F, d13).func_181666_a(r, g, b, 0.25F * alphaMult).func_181675_d();
        worldrenderer.func_181662_b(x + 0.8, y + (double)topOffset, z + 0.2).func_181673_a((double)1.0F, d13).func_181666_a(r, g, b, 0.25F * alphaMult).func_181675_d();
        worldrenderer.func_181662_b(x + 0.8, y + (double)bottomOffset, z + 0.2).func_181673_a((double)1.0F, d12).func_181666_a(r, g, b, 0.25F).func_181675_d();
        worldrenderer.func_181662_b(x + 0.8, y + (double)bottomOffset, z + 0.8).func_181673_a((double)0.0F, d12).func_181666_a(r, g, b, 0.25F).func_181675_d();
        worldrenderer.func_181662_b(x + 0.8, y + (double)topOffset, z + 0.8).func_181673_a((double)0.0F, d13).func_181666_a(r, g, b, 0.25F * alphaMult).func_181675_d();
        worldrenderer.func_181662_b(x + 0.2, y + (double)topOffset, z + 0.8).func_181673_a((double)1.0F, d13).func_181666_a(r, g, b, 0.25F * alphaMult).func_181675_d();
        worldrenderer.func_181662_b(x + 0.2, y + (double)bottomOffset, z + 0.8).func_181673_a((double)1.0F, d12).func_181666_a(r, g, b, 0.25F).func_181675_d();
        worldrenderer.func_181662_b(x + 0.2, y + (double)bottomOffset, z + 0.2).func_181673_a((double)0.0F, d12).func_181666_a(r, g, b, 0.25F).func_181675_d();
        worldrenderer.func_181662_b(x + 0.2, y + (double)topOffset, z + 0.2).func_181673_a((double)0.0F, d13).func_181666_a(r, g, b, 0.25F * alphaMult).func_181675_d();
        tessellator.func_78381_a();
        GlStateManager.func_179140_f();
        GlStateManager.func_179098_w();
        if (disableDepth) {
            GlStateManager.func_179126_j();
        }

    }

    public static void drawColorPicker(int x1, int y1, int x2, int y2) {
        int width = x2 - x1 - 1;

        for(int i = 0; i <= width; ++i) {
            float ratio = (float)i / (float)width;
            int color = Color.HSBtoRGB(ratio, 1.0F, 1.0F);
            Gui.func_73734_a(x1 + i, y1, x1 + i + 1, y2, color);
        }

    }

    public static void drawColorPicker(int x1, int y1, int x2, int y2, int topLeft, int topRight, int bottomLeft, int bottomRight) {
        float a1 = (float)(bottomLeft >> 24 & 255) / 255.0F;
        float r1 = (float)(bottomLeft >> 16 & 255) / 255.0F;
        float g1 = (float)(bottomLeft >> 8 & 255) / 255.0F;
        float b1 = (float)(bottomLeft & 255) / 255.0F;
        float a2 = (float)(bottomRight >> 24 & 255) / 255.0F;
        float r2 = (float)(bottomRight >> 16 & 255) / 255.0F;
        float g2 = (float)(bottomRight >> 8 & 255) / 255.0F;
        float b2 = (float)(bottomRight & 255) / 255.0F;
        float a3 = (float)(topLeft >> 24 & 255) / 255.0F;
        float r3 = (float)(topLeft >> 16 & 255) / 255.0F;
        float g3 = (float)(topLeft >> 8 & 255) / 255.0F;
        float b3 = (float)(topLeft & 255) / 255.0F;
        float a4 = (float)(topRight >> 24 & 255) / 255.0F;
        float r4 = (float)(topRight >> 16 & 255) / 255.0F;
        float g4 = (float)(topRight >> 8 & 255) / 255.0F;
        float b4 = (float)(topRight & 255) / 255.0F;
        GlStateManager.func_179090_x();
        GlStateManager.func_179147_l();
        GlStateManager.func_179118_c();
        GlStateManager.func_179120_a(770, 771, 1, 0);
        GlStateManager.func_179103_j(7425);
        Tessellator tessellator = Tessellator.func_178181_a();
        WorldRenderer worldRenderer = tessellator.func_178180_c();
        worldRenderer.func_181668_a(7, DefaultVertexFormats.field_181706_f);
        worldRenderer.func_181662_b((double)x1, (double)y2, (double)0.0F).func_181666_a(r1, g1, b1, a1).func_181675_d();
        worldRenderer.func_181662_b((double)x2, (double)y2, (double)0.0F).func_181666_a(r2, g2, b2, a2).func_181675_d();
        worldRenderer.func_181662_b((double)x2, (double)y1, (double)0.0F).func_181666_a(r4, g4, b4, a4).func_181675_d();
        worldRenderer.func_181662_b((double)x1, (double)y1, (double)0.0F).func_181666_a(r3, g3, b3, a3).func_181675_d();
        tessellator.func_78381_a();
        GlStateManager.func_179103_j(7424);
        GlStateManager.func_179084_k();
        GlStateManager.func_179141_d();
        GlStateManager.func_179098_w();
    }

    public static void showTitle(String title, int mills) {
        Minecraft.func_71410_x().field_71439_g.func_85030_a("random.orb", 1.0F, 0.5F);
        RenderUtils.title = title;
        untilTitle = System.currentTimeMillis() + (long)mills;
    }

    public static void drawString(String text, int x, int y) {
        if (text != null) {
            for(String line : text.split("\n")) {
                Main.mc.field_71466_p.func_175065_a(line, (float)x, (float)y, 16777215, true);
                y += Main.mc.field_71466_p.field_78288_b;
            }

        }
    }

    public static void drawCenteredString(String text, int x, int y) {
        FontRenderer renderer = Main.mc.field_71466_p;
        int width = renderer.func_78256_a(text);

        for(String line : text.split("\n")) {
            renderer.func_175065_a(line, (float)x - (float)width / 2.0F, (float)y - (float)renderer.field_78288_b / 2.0F, 16777215, true);
            y += renderer.field_78288_b;
        }

    }

    public static void drawString(String text, int x, int y, float scale) {
        double scaleReset = Math.pow((double)scale, (double)-1.0F);
        float y2 = (float)y;
        Minecraft mc = Main.mc;
        GL11.glScaled((double)scale, (double)scale, (double)scale);

        for(String line : text.split("\n")) {
            mc.field_71466_p.func_175065_a(line, (float)x / scale, y2 / scale, 16777215, true);
            y2 += (float)mc.field_71466_p.field_78288_b * scale;
        }

        GL11.glScaled(scaleReset, scaleReset, scaleReset);
        GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
    }

    public static void tracerLine(Entity entity, float offset, float partialTicks, float lineWidth, Color color) {
        double x = entity.field_70169_q + (entity.field_70165_t - entity.field_70169_q) * (double)partialTicks;
        double y = entity.field_70167_r + (double)offset + (entity.field_70163_u - entity.field_70167_r) * (double)partialTicks + (double)(entity.field_70131_O / 2.0F);
        double z = entity.field_70166_s + (entity.field_70161_v - entity.field_70166_s) * (double)partialTicks;
        tracerLine(x, y, z, offset, partialTicks, lineWidth, color);
    }

    public static void tracerLine(double x, double y, double z, float offset, float partialTicks, float lineWidth, Color color) {
        GL11.glBlendFunc(770, 771);
        GL11.glEnable(3042);
        GL11.glDisable(3553);
        GL11.glDisable(2929);
        GL11.glLineWidth(lineWidth);
        GL11.glDepthMask(false);
        setColor(color);
        GL11.glBegin(2);
        GL11.glVertex3d((double)0.0F, (double)Main.mc.field_71439_g.func_70047_e(), (double)0.0F);
        GL11.glVertex3d(x - Main.mc.func_175598_ae().field_78730_l, y - Main.mc.func_175598_ae().field_78731_m, z - Main.mc.func_175598_ae().field_78728_n);
        GL11.glEnd();
        GL11.glEnable(3553);
        GL11.glEnable(2929);
        GL11.glDepthMask(true);
        GL11.glDisable(3042);
        setColor(Color.WHITE);
    }

    public static void renderItem(ItemStack itemStack, int x, int y, float scale) {
        double scaleReset = Math.pow((double)scale, (double)-1.0F);
        GL11.glScaled((double)scale, (double)scale, (double)scale);
        RenderHelper.func_74520_c();
        GlStateManager.func_179126_j();
        Minecraft.func_71410_x().func_175599_af().func_180450_b(itemStack, (int)((float)x / scale), (int)((float)y / scale));
        GL11.glScaled(scaleReset, scaleReset, scaleReset);
        if (itemStack.field_77994_a != 1) {
            GlStateManager.func_179109_b(0.0F, 0.0F, 500.0F);
            String text = String.valueOf(itemStack.field_77994_a);
            drawString(text, x + 17 - Minecraft.func_71410_x().field_71466_p.func_78256_a(text), y + 9);
            GlStateManager.func_179109_b(0.0F, 0.0F, -500.0F);
        }

    }

    public static double interpolate(double currentValue, double lastValue, float multiplier) {
        return lastValue + (currentValue - lastValue) * (double)multiplier;
    }

    public static void drawOutlineBox(BlockPos block, Color color, float lineWidth) {
        drawOutlineBox((double)block.func_177958_n(), (double)block.func_177956_o(), (double)block.func_177952_p(), (double)(block.func_177958_n() + 1), (double)(block.func_177956_o() + 1), (double)(block.func_177952_p() + 1), color, lineWidth);
    }

    public static void drawOutlineBox(double x1, double y1, double z1, double x2, double y2, double z2, Color color, float lineWidth) {
        drawOutlineBox(x1, y1, z1, x2, y2, z2, color, lineWidth, true);
    }

    public static void drawFullBox(BlockPos block, Color color, float lineWidth) {
        drawFullBox((double)block.func_177958_n(), (double)block.func_177956_o(), (double)block.func_177952_p(), (double)(block.func_177958_n() + 1), (double)(block.func_177956_o() + 1), (double)(block.func_177952_p() + 1), color, lineWidth);
    }

    public static void drawFullBox(double x1, double y1, double z1, double x2, double y2, double z2, Color color, float lineWidth) {
        beginDraw();
        GL11.glLineWidth(lineWidth);
        setColor(color);
        AxisAlignedBB aabb = new AxisAlignedBB(x1 - Main.mc.func_175598_ae().field_78730_l, y1 - Main.mc.func_175598_ae().field_78731_m, z1 - Main.mc.func_175598_ae().field_78728_n, x2 - Main.mc.func_175598_ae().field_78730_l, y2 - Main.mc.func_175598_ae().field_78731_m, z2 - Main.mc.func_175598_ae().field_78728_n);
        drawBoundingBox(color, aabb);
        RenderGlobal.func_181561_a(aabb);
        endDraw();
    }

    public static float getPartialTicks() {
        return ((Timer)ObfuscationReflectionHelper.getPrivateValue(Minecraft.class, Minecraft.func_71410_x(), new String[]{"timer", "field_71428_T"})).field_74281_c;
    }

    public static void drawOutlineBox(double x1, double y1, double z1, double x2, double y2, double z2, Color color, float lineWidth, boolean seeThroughWall) {
        Entity render = Minecraft.func_71410_x().func_175606_aa();
        float partialTicks = getPartialTicks();
        double realX = interpolate(render.field_70165_t, render.field_70142_S, partialTicks);
        double realY = interpolate(render.field_70163_u, render.field_70137_T, partialTicks);
        double realZ = interpolate(render.field_70161_v, render.field_70136_U, partialTicks);
        GlStateManager.func_179094_E();
        GlStateManager.func_179137_b(-realX, -realY, -realZ);
        GlStateManager.func_179090_x();
        GlStateManager.func_179147_l();
        GlStateManager.func_179140_f();
        GlStateManager.func_179118_c();
        GlStateManager.func_179120_a(770, 771, 1, 0);
        GL11.glLineWidth(lineWidth);
        if (seeThroughWall) {
            GL11.glDisable(2929);
        }

        RenderGlobal.func_181563_a(new AxisAlignedBB(x1, y1, z1, x2, y2, z2), color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
        if (seeThroughWall) {
            GL11.glEnable(2929);
        }

        GlStateManager.func_179137_b(realX, realY, realZ);
        GlStateManager.func_179084_k();
        GlStateManager.func_179141_d();
        GlStateManager.func_179098_w();
        GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
        GlStateManager.func_179121_F();
    }

    private static void beginDraw() {
        GL11.glBlendFunc(770, 771);
        GL11.glEnable(3042);
        GL11.glDisable(3553);
        GL11.glDisable(2929);
        GL11.glDepthMask(false);
    }

    private static void endDraw() {
        GL11.glEnable(3553);
        GL11.glEnable(2929);
        GL11.glDepthMask(true);
        GL11.glDisable(3042);
    }

    private static void drawBoundingBox(Color c, AxisAlignedBB aa) {
        Tessellator tessellator = Tessellator.func_178181_a();
        WorldRenderer worldRenderer = tessellator.func_178180_c();
        int color = c.getRGB();
        float a = (float)(color >> 24 & 255) / 255.0F;
        a = (float)((double)a * 0.2);
        float r = (float)(color >> 16 & 255) / 255.0F;
        float g = (float)(color >> 8 & 255) / 255.0F;
        float b = (float)(color & 255) / 255.0F;
        worldRenderer.func_181668_a(7, DefaultVertexFormats.field_181706_f);
        worldRenderer.func_181662_b(aa.field_72340_a, aa.field_72337_e, aa.field_72339_c).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72340_a, aa.field_72338_b, aa.field_72339_c).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72336_d, aa.field_72337_e, aa.field_72339_c).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72336_d, aa.field_72338_b, aa.field_72339_c).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72336_d, aa.field_72337_e, aa.field_72334_f).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72336_d, aa.field_72338_b, aa.field_72334_f).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72340_a, aa.field_72337_e, aa.field_72334_f).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72340_a, aa.field_72338_b, aa.field_72334_f).func_181666_a(r, g, b, a).func_181675_d();
        tessellator.func_78381_a();
        worldRenderer.func_181668_a(7, DefaultVertexFormats.field_181706_f);
        worldRenderer.func_181662_b(aa.field_72336_d, aa.field_72338_b, aa.field_72339_c).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72336_d, aa.field_72337_e, aa.field_72339_c).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72340_a, aa.field_72338_b, aa.field_72339_c).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72340_a, aa.field_72337_e, aa.field_72339_c).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72340_a, aa.field_72338_b, aa.field_72334_f).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72340_a, aa.field_72337_e, aa.field_72334_f).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72336_d, aa.field_72338_b, aa.field_72334_f).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72336_d, aa.field_72337_e, aa.field_72334_f).func_181666_a(r, g, b, a).func_181675_d();
        tessellator.func_78381_a();
        worldRenderer.func_181668_a(7, DefaultVertexFormats.field_181706_f);
        worldRenderer.func_181662_b(aa.field_72340_a, aa.field_72338_b, aa.field_72339_c).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72336_d, aa.field_72338_b, aa.field_72339_c).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72336_d, aa.field_72338_b, aa.field_72334_f).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72340_a, aa.field_72338_b, aa.field_72334_f).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72340_a, aa.field_72338_b, aa.field_72339_c).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72340_a, aa.field_72338_b, aa.field_72334_f).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72336_d, aa.field_72338_b, aa.field_72334_f).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72336_d, aa.field_72338_b, aa.field_72339_c).func_181666_a(r, g, b, a).func_181675_d();
        tessellator.func_78381_a();
        worldRenderer.func_181668_a(7, DefaultVertexFormats.field_181706_f);
        worldRenderer.func_181662_b(aa.field_72340_a, aa.field_72337_e, aa.field_72339_c).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72336_d, aa.field_72337_e, aa.field_72339_c).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72336_d, aa.field_72337_e, aa.field_72334_f).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72340_a, aa.field_72337_e, aa.field_72334_f).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72340_a, aa.field_72337_e, aa.field_72339_c).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72340_a, aa.field_72337_e, aa.field_72334_f).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72336_d, aa.field_72337_e, aa.field_72334_f).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72336_d, aa.field_72337_e, aa.field_72339_c).func_181666_a(r, g, b, a).func_181675_d();
        tessellator.func_78381_a();
        worldRenderer.func_181668_a(7, DefaultVertexFormats.field_181706_f);
        worldRenderer.func_181662_b(aa.field_72340_a, aa.field_72337_e, aa.field_72339_c).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72340_a, aa.field_72338_b, aa.field_72339_c).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72340_a, aa.field_72337_e, aa.field_72334_f).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72340_a, aa.field_72338_b, aa.field_72334_f).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72336_d, aa.field_72337_e, aa.field_72334_f).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72336_d, aa.field_72338_b, aa.field_72334_f).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72336_d, aa.field_72337_e, aa.field_72339_c).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72336_d, aa.field_72338_b, aa.field_72339_c).func_181666_a(r, g, b, a).func_181675_d();
        tessellator.func_78381_a();
        worldRenderer.func_181668_a(7, DefaultVertexFormats.field_181706_f);
        worldRenderer.func_181662_b(aa.field_72340_a, aa.field_72338_b, aa.field_72334_f).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72340_a, aa.field_72337_e, aa.field_72334_f).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72340_a, aa.field_72338_b, aa.field_72339_c).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72340_a, aa.field_72337_e, aa.field_72339_c).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72336_d, aa.field_72338_b, aa.field_72339_c).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72336_d, aa.field_72337_e, aa.field_72339_c).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72336_d, aa.field_72338_b, aa.field_72334_f).func_181666_a(r, g, b, a).func_181675_d();
        worldRenderer.func_181662_b(aa.field_72336_d, aa.field_72337_e, aa.field_72334_f).func_181666_a(r, g, b, a).func_181675_d();
        tessellator.func_78381_a();
    }

    public static void draw3DString(double x, double y, double z, String text, int colour, float partialTicks) {
        GlStateManager.func_179092_a(516, 0.1F);
        GlStateManager.func_179094_E();
        Entity viewer = Minecraft.func_71410_x().func_175606_aa();
        double viewerX = viewer.field_70142_S + (viewer.field_70165_t - viewer.field_70142_S) * (double)partialTicks;
        double viewerY = viewer.field_70137_T + (viewer.field_70163_u - viewer.field_70137_T) * (double)partialTicks;
        double viewerZ = viewer.field_70136_U + (viewer.field_70161_v - viewer.field_70136_U) * (double)partialTicks;
        x -= viewerX;
        y = y - viewerY - (double)viewer.func_70047_e();
        z -= viewerZ;
        double distSq = x * x + y * y + z * z;
        double dist = Math.sqrt(distSq);
        double a = (double)4.0F;
        if (distSq > a * a) {
            x *= a / dist;
            y *= a / dist;
            z *= a / dist;
        }

        GlStateManager.func_179137_b(x, y, z);
        GlStateManager.func_179109_b(0.0F, viewer.func_70047_e(), 0.0F);
        FontRenderer fontrenderer = Minecraft.func_71410_x().field_71466_p;
        float f = 1.3F;
        float f1 = 0.016666668F * f;
        GlStateManager.func_179094_E();
        GL11.glNormal3f(0.0F, 1.0F, 0.0F);
        GlStateManager.func_179114_b(-Minecraft.func_71410_x().func_175598_ae().field_78735_i, 0.0F, 1.0F, 0.0F);
        GlStateManager.func_179114_b(Minecraft.func_71410_x().func_175598_ae().field_78732_j, 1.0F, 0.0F, 0.0F);
        GlStateManager.func_179152_a(-f1, -f1, f1);
        GlStateManager.func_179140_f();
        GlStateManager.func_179132_a(false);
        GlStateManager.func_179097_i();
        GlStateManager.func_179147_l();
        GlStateManager.func_179120_a(770, 771, 1, 0);
        Tessellator tessellator = Tessellator.func_178181_a();
        WorldRenderer worldrenderer = tessellator.func_178180_c();
        int i = 0;
        int j = fontrenderer.func_78256_a(text) / 2;
        GlStateManager.func_179090_x();
        worldrenderer.func_181668_a(7, DefaultVertexFormats.field_181706_f);
        worldrenderer.func_181662_b((double)(-j - 1), (double)(-1 + i), (double)0.0F).func_181666_a(0.0F, 0.0F, 0.0F, 0.25F).func_181675_d();
        worldrenderer.func_181662_b((double)(-j - 1), (double)(8 + i), (double)0.0F).func_181666_a(0.0F, 0.0F, 0.0F, 0.25F).func_181675_d();
        worldrenderer.func_181662_b((double)(j + 1), (double)(8 + i), (double)0.0F).func_181666_a(0.0F, 0.0F, 0.0F, 0.25F).func_181675_d();
        worldrenderer.func_181662_b((double)(j + 1), (double)(-1 + i), (double)0.0F).func_181666_a(0.0F, 0.0F, 0.0F, 0.25F).func_181675_d();
        tessellator.func_78381_a();
        GlStateManager.func_179098_w();
        fontrenderer.func_78276_b(text, -fontrenderer.func_78256_a(text) / 2, i, 553648127);
        GlStateManager.func_179132_a(true);
        fontrenderer.func_78276_b(text, -fontrenderer.func_78256_a(text) / 2, i, -1);
        GlStateManager.func_179126_j();
        GlStateManager.func_179147_l();
        GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
        GlStateManager.func_179121_F();
        GlStateManager.func_179121_F();
        GlStateManager.func_179140_f();
    }

    public static void draw3DString(BlockPos pos, String text, int colour, float partialTicks) {
        draw3DString((double)pos.func_177958_n(), (double)pos.func_177956_o(), (double)pos.func_177952_p(), text, colour, partialTicks);
    }

    private static void setColor(Color c) {
        GL11.glColor4f((float)c.getRed() / 255.0F, (float)c.getGreen() / 255.0F, (float)c.getBlue() / 255.0F, (float)c.getAlpha() / 255.0F);
    }

    public static void drawOutlineEntityBox(Entity entity, Color color) {
        AxisAlignedBB aabb = entity.func_174813_aQ();
        drawOutlineEntityBox(entity, aabb.field_72336_d - aabb.field_72340_a, aabb.field_72337_e - aabb.field_72338_b, aabb.field_72334_f - aabb.field_72339_c, (double)0.0F, (double)0.0F, (double)0.0F, color, 2.0F, true);
    }

    public static void drawOutlineEntityBox(Entity entity, Color color, float lineWidth, boolean seeThroughWall) {
        AxisAlignedBB aabb = entity.func_174813_aQ();
        drawOutlineEntityBox(entity, aabb.field_72336_d - aabb.field_72340_a, aabb.field_72337_e - aabb.field_72338_b, aabb.field_72334_f - aabb.field_72339_c, (double)0.0F, (double)0.0F, (double)0.0F, color, lineWidth, seeThroughWall);
    }

    public static void drawOutlineEntityBox(Entity entity, double sizeX, double sizeY, double sizeZ, double offsetX, double offsetY, double offsetZ, Color color, float lineWidth, boolean seeThroughWall) {
        float partialTicks = getPartialTicks();
        drawOutlineBox(offsetX + (entity.field_70165_t - sizeX / (double)2.0F) - entity.field_70165_t + entity.field_70169_q + (entity.field_70165_t - entity.field_70169_q) * (double)partialTicks, offsetY + entity.field_70167_r + (entity.field_70163_u - entity.field_70167_r) * (double)partialTicks, offsetZ + (entity.field_70161_v - sizeZ / (double)2.0F) - entity.field_70161_v + entity.field_70166_s + (entity.field_70161_v - entity.field_70166_s) * (double)partialTicks, offsetX + entity.field_70165_t + sizeX / (double)2.0F - entity.field_70165_t + entity.field_70169_q + (entity.field_70165_t - entity.field_70169_q) * (double)partialTicks, offsetY + entity.field_70163_u + sizeY - entity.field_70163_u + entity.field_70167_r + (entity.field_70163_u - entity.field_70167_r) * (double)partialTicks, offsetZ + entity.field_70161_v + sizeZ / (double)2.0F - entity.field_70161_v + entity.field_70166_s + (entity.field_70161_v - entity.field_70166_s) * (double)partialTicks, color, lineWidth, seeThroughWall);
    }

    public static void drawOnSlot(int size, int xSlotPos, int ySlotPos, int colour) {
        ScaledResolution sr = new ScaledResolution(Minecraft.func_71410_x());
        int guiLeft = (sr.func_78326_a() - 176) / 2;
        int guiTop = (sr.func_78328_b() - 222) / 2;
        int x = guiLeft + xSlotPos;
        int y = guiTop + ySlotPos;
        if (size != 90) {
            y += (6 - (size - 36) / 9) * 9;
        }

        GL11.glTranslated((double)0.0F, (double)0.0F, (double)1.0F);
        Gui.func_73734_a(x, y, x + 16, y + 16, colour);
        GL11.glTranslated((double)0.0F, (double)0.0F, (double)-1.0F);
    }

    public static void drawOutlineSlot(int slotX, int slotY, int colour) {
        ScaledResolution sr = new ScaledResolution(Minecraft.func_71410_x());
        int guiLeft = (sr.func_78326_a() - 176) / 2;
        int guiTop = (sr.func_78328_b() - 222) / 2;
        int x = guiLeft + slotX;
        int y = guiTop + slotY;
        GL11.glTranslated((double)0.0F, (double)0.0F, (double)1.0F);
        Gui.func_73734_a(x, y, x + 16, y + 1, colour);
        Gui.func_73734_a(x, y + 15, x + 16, y + 16, colour);
        Gui.func_73734_a(x, y, x + 1, y + 16, colour);
        Gui.func_73734_a(x + 15, y, x + 16, y + 16, colour);
        GL11.glTranslated((double)0.0F, (double)0.0F, (double)-1.0F);
    }

    @SubscribeEvent
    public void renderOverlay(RenderOverlayEvent event) {
        if (RenderUtils.title != null && untilTitle - System.currentTimeMillis() > 0L) {
            Minecraft mc = Minecraft.func_71410_x();
            ScaledResolution scaledResolution = new ScaledResolution(mc);
            int height = scaledResolution.func_78328_b();
            int width = scaledResolution.func_78326_a();
            String[] splitText = RenderUtils.title.split("\n");

            for(String title : splitText) {
                int textLength = mc.field_71466_p.func_78256_a(title);
                float scale = 4.0F;
                if ((float)textLength * scale > (float)width * 0.9F) {
                    scale = (float)width * 0.9F / (float)textLength;
                }

                int titleX = (int)((float)(width / 2) - (float)textLength * scale / 2.0F);
                int titleY = height / 2 - 100;
                drawString(title, titleX, titleY, scale);
            }

        }
    }
}
