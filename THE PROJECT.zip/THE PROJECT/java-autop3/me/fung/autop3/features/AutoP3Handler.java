//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3.features;

import java.awt.Color;
import java.util.ArrayList;
import me.fung.autop3.ConfigGui;
import me.fung.autop3.events.PacketReceivedEvent;
import me.fung.autop3.events.PacketSentEvent;
import me.fung.autop3.ring.RingType;
import me.fung.autop3.utils.MathUtils;
import me.fung.autop3.utils.RenderUtils;
import me.fung.autop3.utils.SkyblockUtils;
import me.fung.autop3.utils.Utils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.Phase;

public class AutoP3Handler {
    public static final ArrayList<RingType> deactivateRings = new ArrayList();
    private static boolean terminalPass;
    public static double nextLaunchY = (double)-1.0F;
    private static double lastPosX = Double.NaN;
    private static double lastPosY;
    private static double lastPosZ;
    public static RingType settingRing;

    @SubscribeEvent(
            priority = EventPriority.HIGHEST
    )
    public void onTick(TickEvent.PlayerTickEvent event) {
        if (event.phase == Phase.START && Utils.isInGame() && event.player == Minecraft.func_71410_x().field_71439_g) {
            if (ConfigGui.INSTANCE.autoP3Toggle && (!ConfigGui.INSTANCE.onlyActivateInP3 || SkyblockUtils.inP3)) {
                this.run();
            }

        }
    }

    public void run() {
        Minecraft mc = Minecraft.func_71410_x();
        EntityPlayerSP player = mc.field_71439_g;
        if (!Double.isNaN(lastPosX)) {
            deactivateRings.removeIf((ringx) -> {
                double radius = ringx.width / (double)2.0F;
                MathUtils.Box box = new MathUtils.Box(ringx.x - radius, ringx.y, ringx.z - radius, ringx.x + radius, ringx.y + ringx.height, ringx.z + radius);
                return !box.intersects(lastPosX, lastPosY, lastPosZ, player.field_70165_t, player.field_70163_u, player.field_70161_v);
            });

            for(RingType ring : RingType.getCurrentPresetRings()) {
                if (!deactivateRings.contains(ring)) {
                    double radius = ring.width / (double)2.0F;
                    MathUtils.Box box = new MathUtils.Box(ring.x - radius, ring.y, ring.z - radius, ring.x + radius, ring.y + ring.height, ring.z + radius);
                    if (box.intersects(lastPosX, lastPosY, lastPosZ, player.field_70165_t, player.field_70163_u, player.field_70161_v)) {
                        if (ring.awaitTerm) {
                            if (!terminalPass) {
                                return;
                            }

                            player.field_70159_w = (double)0.0F;
                            player.field_70179_y = (double)0.0F;
                        }

                        if (ring.run()) {
                            deactivateRings.add(ring);
                        }
                    }
                }
            }

            terminalPass = false;
        }

        lastPosX = player.field_70165_t;
        lastPosY = player.field_70163_u;
        lastPosZ = player.field_70161_v;
    }

    @SubscribeEvent
    public void onPacketSent(PacketSentEvent event) {
        if (event.packet instanceof C02PacketUseEntity) {
            C02PacketUseEntity packet = (C02PacketUseEntity)event.packet;
            Minecraft mc = Minecraft.func_71410_x();
            Entity entity = packet.func_149564_a(mc.field_71441_e);
            if (!(entity instanceof EntityArmorStand)) {
                return;
            }

            EntityArmorStand armorStand = (EntityArmorStand)entity;
            if ("§cInactive Terminal".equals(armorStand.func_70005_c_())) {
                terminalPass = true;
            }
        }

    }

    @SubscribeEvent
    public void onPacketReceived(PacketReceivedEvent event) {
        if (event.packet instanceof S12PacketEntityVelocity && nextLaunchY != (double)-1.0F) {
            S12PacketEntityVelocity packet = (S12PacketEntityVelocity)event.packet;
            Minecraft mc = Minecraft.func_71410_x();
            EntityPlayerSP player = mc.field_71439_g;
            Entity entity = mc.field_71441_e.func_73045_a(packet.func_149412_c());
            if (player == entity) {
                int motionY = packet.func_149410_e();
                if (motionY == 28000) {
                    Utils.addChatMessage("Launch!");
                    event.setCanceled(true);
                    player.func_70016_h((double)packet.func_149411_d() / (double)8000.0F, nextLaunchY, (double)packet.func_149409_f() / (double)8000.0F);
                    nextLaunchY = (double)-1.0F;
                }
            }
        }
    }

    @SubscribeEvent
    public void onWorldRender(RenderWorldLastEvent event) {
        if (ConfigGui.INSTANCE.autoP3Toggle) {
            if (!ConfigGui.INSTANCE.onlyActivateInP3 || SkyblockUtils.inP3) {
                for(RingType ring : RingType.getCurrentPresetRings()) {
                    if (!ConfigGui.INSTANCE.hideDeactivateRings || !deactivateRings.contains(ring)) {
                        Color ringColor = ConfigGui.INSTANCE.showSelectingRing && settingRing == ring ? ConfigGui.INSTANCE.selectingRingColor : ring.getRingColor();
                        float radius = (float)(ring.width / (double)2.0F);
                        double ringX = ring.x;
                        double ringY = ring.y;
                        double ringZ = ring.z;
                        switch (ConfigGui.INSTANCE.displayMode) {
                            case 0:
                                RenderUtils.renderRing(ringX, ringY + 0.02, ringZ, radius, radius, 0.01F, 60, 1, 90, 0, 0, true, ringColor, ConfigGui.INSTANCE.seeThroughWall);
                                if (ring.awaitTerm) {
                                    RenderUtils.renderRing(ringX, ringY + 0.02, ringZ, radius - 0.05F, radius - 0.05F, 0.01F, 60, 1, 90, 0, 0, true, Color.WHITE, ConfigGui.INSTANCE.seeThroughWall);
                                }
                                break;
                            case 1:
                                RenderUtils.drawOutlineBox(ringX - (double)radius, ringY, ringZ - (double)radius, ringX + (double)radius, ringY + ring.height, ringZ + (double)radius, ringColor, 2.0F, ConfigGui.INSTANCE.seeThroughWall);
                        }
                    }
                }
            }

        }
    }
}
