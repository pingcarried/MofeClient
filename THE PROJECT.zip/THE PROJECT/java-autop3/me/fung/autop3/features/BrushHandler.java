//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3.features;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import java.util.HashMap;
import java.util.Map;
import me.fung.autop3.ConfigGui;
import me.fung.autop3.Preset;
import me.fung.autop3.events.PacketSentEvent;
import me.fung.autop3.events.TickStartEvent;
import me.fung.autop3.utils.Config;
import me.fung.autop3.utils.Utils;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent.Action;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class BrushHandler {
    public static boolean editMode;
    public static IBlockState setState;
    public static HashMap<Preset, HashMap<BlockPos, IBlockState>> presetBlocks;

    public static HashMap<BlockPos, IBlockState> getCurrentPresetBlocks() {
        return getPresetBlocks(Preset.getCurrentPreset());
    }

    public static HashMap<BlockPos, IBlockState> getPresetBlocks(Preset preset) {
        if (!presetBlocks.containsKey(preset)) {
            HashMap<BlockPos, IBlockState> map = new HashMap();
            presetBlocks.put(preset, map);
            return map;
        } else {
            return (HashMap)presetBlocks.get(preset);
        }
    }

    @SubscribeEvent
    public void onTick(TickStartEvent event) {
        for(Map.Entry<BlockPos, IBlockState> entry : getCurrentPresetBlocks().entrySet()) {
            Minecraft.func_71410_x().field_71441_e.func_175656_a((BlockPos)entry.getKey(), (IBlockState)entry.getValue());
        }

    }

    @SubscribeEvent
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (event.action == Action.RIGHT_CLICK_BLOCK) {
            EntityPlayerSP player = Minecraft.func_71410_x().field_71439_g;
            if (event.entityPlayer == player) {
                BlockPos pos = event.pos.func_177967_a(event.face, 1);
                HashMap<BlockPos, IBlockState> blocks = getCurrentPresetBlocks();
                if (editMode) {
                    if (blocks.containsKey(pos)) {
                        blocks.remove(pos);
                    } else {
                        blocks.put(pos, setState);
                        event.setCanceled(true);
                    }
                } else if (blocks.containsKey(event.pos)) {
                    event.setCanceled(true);
                }

            }
        }
    }

    @SubscribeEvent
    public void onPacketSent(PacketSentEvent event) {
        if (event.packet instanceof C07PacketPlayerDigging) {
            C07PacketPlayerDigging packet = (C07PacketPlayerDigging)event.packet;
            BlockPos pos = packet.func_179715_a();
            HashMap<BlockPos, IBlockState> blocks = getCurrentPresetBlocks();
            boolean isBrushBlock = blocks.containsKey(pos);
            World world = Minecraft.func_71410_x().field_71441_e;
            if (isBrushBlock) {
                event.setCanceled(true);
            }

            if (editMode && packet.func_180762_c() == net.minecraft.network.play.client.C07PacketPlayerDigging.Action.START_DESTROY_BLOCK) {
                if (isBrushBlock) {
                    blocks.remove(pos);
                } else {
                    blocks.put(pos, Blocks.field_150350_a.func_176223_P());
                }

                world.func_175698_g(pos);
            }

        }
    }

    public static void saveConfig() {
        Config config = new Config("blocks.json");
        JsonObject configObject = new JsonObject();

        for(Map.Entry<Preset, HashMap<BlockPos, IBlockState>> presetEntry : presetBlocks.entrySet()) {
            HashMap<BlockPos, IBlockState> blocks = (HashMap)presetEntry.getValue();
            HashMap<IBlockState, JsonArray> arrayMap = new HashMap();

            for(Map.Entry<BlockPos, IBlockState> blockEntry : blocks.entrySet()) {
                JsonArray array;
                if (!arrayMap.containsKey(blockEntry.getValue())) {
                    array = new JsonArray();
                    arrayMap.put(blockEntry.getValue(), array);
                } else {
                    array = (JsonArray)arrayMap.get(blockEntry.getValue());
                }

                BlockPos pos = (BlockPos)blockEntry.getKey();
                JsonArray posIntArray = new JsonArray();
                posIntArray.add(new JsonPrimitive(pos.func_177958_n()));
                posIntArray.add(new JsonPrimitive(pos.func_177956_o()));
                posIntArray.add(new JsonPrimitive(pos.func_177952_p()));
                array.add(posIntArray);
            }

            JsonObject blocksObject = new JsonObject();

            for(Map.Entry<IBlockState, JsonArray> entry : arrayMap.entrySet()) {
                IBlockState blockState = (IBlockState)entry.getKey();
                int id = Block.func_176210_f(blockState);
                blocksObject.add(blockState.func_177230_c().getRegistryName() + "|" + (id >> 12 & 15), (JsonElement)entry.getValue());
            }

            configObject.add(((Preset)presetEntry.getKey()).presetName, blocksObject);
        }

        Utils.addChatMessage(configObject.toString());
        config.save();
    }

    public static void loadConfig() {
        new Config("blocks.json");
        Preset preset = Preset.values()[ConfigGui.INSTANCE.configMode];
    }

    static {
        setState = Blocks.field_150399_cn.func_176223_P();
        presetBlocks = new HashMap();
    }
}
