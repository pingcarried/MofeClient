//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3.features;

import me.fung.autop3.ConfigGui;
import me.fung.autop3.events.TickStartEvent;
import me.fung.autop3.utils.PlayerUtils;
import me.fung.autop3.utils.Utils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

public class OldMotionHandler {
    public static final OldMotionHandler INSTANCE = new OldMotionHandler();
    public boolean motioning;
    public boolean prevForward;
    public boolean prevLeft;
    public boolean prevRight;
    public boolean prevBackward;
    public boolean prevSneak;
    public boolean motionOnGround;
    private double yaw;
    private double x;
    private double y;
    private double z;
    private static long lastMidAir;

    public static boolean motion(double yaw) {
        EntityPlayerSP player = Minecraft.func_71410_x().field_71439_g;
        player.field_70159_w = (double)0.0F;
        player.field_70179_y = (double)0.0F;
        INSTANCE.motioning = false;
        long current = System.currentTimeMillis();
        if (!player.field_70122_E) {
            lastMidAir = current;
            return false;
        } else if (current < lastMidAir + (long)ConfigGui.INSTANCE.motionOnGroundCD) {
            return false;
        } else {
            Utils.addChatMessage("Motion");
            Utils.scheduleTask(0, () -> {
                Utils.setKeyBindState(Minecraft.func_71410_x().field_71474_y.field_74311_E, false);

                for(KeyBinding keyBind : PlayerUtils.MOVEMENT_KEYS) {
                    Utils.setKeyBindState(keyBind, false);
                }

                double speed = (double)(player.field_71075_bZ.func_75094_b() * ConfigGui.INSTANCE.motionStrength);
                player.field_70159_w = -Math.sin(yaw * Math.PI / (double)180.0F) * speed;
                player.field_70179_y = Math.cos(yaw * Math.PI / (double)180.0F) * speed;
                player.func_70664_aZ();
            });
            Utils.scheduleTask(1, () -> {
                INSTANCE.yaw = yaw;
                INSTANCE.motion();
            });
            return true;
        }
    }

    private void motion() {
        INSTANCE.motioning = true;
        INSTANCE.prevForward = Keyboard.isKeyDown(Minecraft.func_71410_x().field_71474_y.field_74351_w.func_151463_i());
        INSTANCE.prevLeft = Keyboard.isKeyDown(Minecraft.func_71410_x().field_71474_y.field_74370_x.func_151463_i());
        INSTANCE.prevRight = Keyboard.isKeyDown(Minecraft.func_71410_x().field_71474_y.field_74366_z.func_151463_i());
        INSTANCE.prevBackward = Keyboard.isKeyDown(Minecraft.func_71410_x().field_71474_y.field_74368_y.func_151463_i());
        INSTANCE.prevSneak = Keyboard.isKeyDown(Minecraft.func_71410_x().field_71474_y.field_74368_y.func_151463_i());
    }

    public static void walk(double yaw) {
        Utils.scheduleTask(0, () -> {
            Utils.setKeyBindState(Minecraft.func_71410_x().field_71474_y.field_74311_E, false);

            for(KeyBinding keyBind : PlayerUtils.MOVEMENT_KEYS) {
                Utils.setKeyBindState(keyBind, false);
            }

            INSTANCE.yaw = yaw;
            INSTANCE.motion();
        });
    }

    @SubscribeEvent
    public void onTick(TickStartEvent event) {
        Minecraft mc = Minecraft.func_71410_x();
        if (Utils.isInGame() && this.motioning) {
            EntityPlayerSP player = mc.field_71439_g;
            if (player.func_180799_ab()) {
                this.motioning = false;
            } else {
                boolean forward = Keyboard.isKeyDown(mc.field_71474_y.field_74351_w.func_151463_i());
                boolean left = Keyboard.isKeyDown(mc.field_71474_y.field_74370_x.func_151463_i());
                boolean right = Keyboard.isKeyDown(mc.field_71474_y.field_74366_z.func_151463_i());
                boolean backward = Keyboard.isKeyDown(mc.field_71474_y.field_74368_y.func_151463_i());
                boolean sneak = Keyboard.isKeyDown(mc.field_71474_y.field_74311_E.func_151463_i());
                if ((this.prevForward == forward || !forward) && (this.prevLeft == left || !left) && (this.prevRight == right || !right) && (this.prevBackward == backward || !backward) && (this.prevSneak == sneak || !sneak)) {
                    this.prevForward = forward;
                    if (player.field_70122_E) {
                        double speed = (double)player.field_71075_bZ.func_75094_b() * (double)2.5F;
                        player.field_70159_w = -Math.sin(this.yaw * Math.PI / (double)180.0F) * speed;
                        player.field_70179_y = Math.cos(this.yaw * Math.PI / (double)180.0F) * speed;
                    } else {
                        double drag = 0.905;
                        player.field_70159_w *= drag;
                        player.field_70179_y *= drag;
                        player.field_70159_w *= 1.12;
                        player.field_70179_y *= 1.12;
                    }

                } else {
                    this.motioning = false;
                    Utils.addChatMessage("Stop motion");
                }
            }
        }
    }
}
