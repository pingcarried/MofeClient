//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3.mixins;

import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin({EntityLivingBase.class})
public abstract class MixinEntityLivingBase extends MixinEntity {
    @Overwrite
    public void func_70612_e(float p_moveEntityWithHeading_1_, float p_moveEntityWithHeading_2_) {
        EntityLivingBase thiz = (EntityLivingBase)this;
        if (thiz.func_70613_aW()) {
            if (!thiz.func_70090_H() || thiz instanceof EntityPlayer && ((EntityPlayer)thiz).field_71075_bZ.field_75100_b) {
                if (!thiz.func_180799_ab() || thiz instanceof EntityPlayer && ((EntityPlayer)thiz).field_71075_bZ.field_75100_b) {
                    float f4 = 0.91F;
                    if (thiz.field_70122_E) {
                        f4 = thiz.field_70170_p.func_180495_p(new BlockPos(MathHelper.func_76128_c(thiz.field_70165_t), MathHelper.func_76128_c(thiz.func_174813_aQ().field_72338_b) - 1, MathHelper.func_76128_c(thiz.field_70161_v))).func_177230_c().field_149765_K * 0.91F;
                    }

                    float f = 0.16277136F / (f4 * f4 * f4);
                    float f5;
                    if (thiz.field_70122_E) {
                        f5 = thiz.func_70689_ay() * f;
                    } else {
                        f5 = thiz.field_70747_aH;
                    }

                    thiz.func_70060_a(p_moveEntityWithHeading_1_, p_moveEntityWithHeading_2_, f5);
                    f4 = 0.91F;
                    if (thiz.field_70122_E) {
                        f4 = thiz.field_70170_p.func_180495_p(new BlockPos(MathHelper.func_76128_c(thiz.field_70165_t), MathHelper.func_76128_c(thiz.func_174813_aQ().field_72338_b) - 1, MathHelper.func_76128_c(thiz.field_70161_v))).func_177230_c().field_149765_K * 0.91F;
                    }

                    if (thiz.func_70617_f_()) {
                        float f6 = 0.15F;
                        thiz.field_70159_w = MathHelper.func_151237_a(thiz.field_70159_w, (double)(-f6), (double)f6);
                        thiz.field_70179_y = MathHelper.func_151237_a(thiz.field_70179_y, (double)(-f6), (double)f6);
                        thiz.field_70143_R = 0.0F;
                        if (thiz.field_70181_x < -0.15) {
                            thiz.field_70181_x = -0.15;
                        }

                        boolean flag = thiz.func_70093_af() && thiz instanceof EntityPlayer;
                        if (flag && thiz.field_70181_x < (double)0.0F) {
                            thiz.field_70181_x = (double)0.0F;
                        }
                    }

                    thiz.func_70091_d(thiz.field_70159_w, thiz.field_70181_x, thiz.field_70179_y);
                    if (thiz.field_70123_F && thiz.func_70617_f_()) {
                        thiz.field_70181_x = 0.2;
                    }

                    if (thiz.field_70170_p.field_72995_K && (!thiz.field_70170_p.func_175667_e(new BlockPos((int)thiz.field_70165_t, 0, (int)thiz.field_70161_v)) || !thiz.field_70170_p.func_175726_f(new BlockPos((int)thiz.field_70165_t, 0, (int)thiz.field_70161_v)).func_177410_o())) {
                        if (thiz.field_70163_u > (double)0.0F) {
                            thiz.field_70181_x = -0.1;
                        } else {
                            thiz.field_70181_x = (double)0.0F;
                        }
                    } else {
                        thiz.field_70181_x -= 0.08;
                    }

                    thiz.field_70181_x *= (double)0.98F;
                    thiz.field_70159_w *= (double)f4;
                    thiz.field_70179_y *= (double)f4;
                } else {
                    double d0 = thiz.field_70163_u;
                    thiz.func_70060_a(p_moveEntityWithHeading_1_, p_moveEntityWithHeading_2_, 0.02F);
                    thiz.func_70091_d(thiz.field_70159_w, thiz.field_70181_x, thiz.field_70179_y);
                    thiz.field_70159_w *= (double)0.5F;
                    thiz.field_70181_x *= (double)0.5F;
                    thiz.field_70179_y *= (double)0.5F;
                    thiz.field_70181_x -= 0.02;
                    if (thiz.field_70123_F && thiz.func_70038_c(thiz.field_70159_w, thiz.field_70181_x + (double)0.6F - thiz.field_70163_u + d0, thiz.field_70179_y)) {
                        thiz.field_70181_x = (double)0.3F;
                    }
                }
            } else {
                double d0 = thiz.field_70163_u;
                float f5 = 0.8F;
                float f6 = 0.02F;
                float f3 = (float)EnchantmentHelper.func_180318_b(thiz);
                if (f3 > 3.0F) {
                    f3 = 3.0F;
                }

                if (!thiz.field_70122_E) {
                    f3 *= 0.5F;
                }

                if (f3 > 0.0F) {
                    f5 += (0.54600006F - f5) * f3 / 3.0F;
                    f6 += (thiz.func_70689_ay() * 1.0F - f6) * f3 / 3.0F;
                }

                thiz.func_70060_a(p_moveEntityWithHeading_1_, p_moveEntityWithHeading_2_, f6);
                thiz.func_70091_d(thiz.field_70159_w, thiz.field_70181_x, thiz.field_70179_y);
                thiz.field_70159_w *= (double)f5;
                thiz.field_70181_x *= (double)0.8F;
                thiz.field_70179_y *= (double)f5;
                thiz.field_70181_x -= 0.02;
                if (thiz.field_70123_F && thiz.func_70038_c(thiz.field_70159_w, thiz.field_70181_x + (double)0.6F - thiz.field_70163_u + d0, thiz.field_70179_y)) {
                    thiz.field_70181_x = (double)0.3F;
                }
            }
        }

        thiz.field_70722_aY = thiz.field_70721_aZ;
        double d0 = thiz.field_70165_t - thiz.field_70169_q;
        double d3 = thiz.field_70161_v - thiz.field_70166_s;
        float f3 = MathHelper.func_76133_a(d0 * d0 + d3 * d3) * 4.0F;
        if (f3 > 1.0F) {
            f3 = 1.0F;
        }

        thiz.field_70721_aZ += (f3 - thiz.field_70721_aZ) * 0.4F;
        thiz.field_70754_ba += thiz.field_70721_aZ;
    }
}
