//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3.mixins;

import me.fung.autop3.features.MotionHandler;
import net.minecraft.client.entity.EntityPlayerSP;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin({EntityPlayerSP.class})
public abstract class MixinEntityPlayerSP extends MixinEntityLivingBase {
    public void func_70612_e(float p_moveEntityWithHeading_1_, float p_moveEntityWithHeading_2_) {
        if (MotionHandler.INSTANCE.moveEntityWithHeading(p_moveEntityWithHeading_1_, p_moveEntityWithHeading_2_)) {
            super.func_70612_e(p_moveEntityWithHeading_1_, p_moveEntityWithHeading_2_);
        }

    }

    @Shadow
    public abstract boolean func_70613_aW();
}
