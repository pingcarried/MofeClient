//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3.command;

import java.util.List;
import me.fung.autop3.ConfigGui;
import me.fung.autop3.features.AutoP3Handler;
import me.fung.autop3.ring.RingType;
import me.fung.autop3.ring.types.CommandRing;
import me.fung.autop3.ring.types.HClipRing;
import me.fung.autop3.ring.types.JumpRing;
import me.fung.autop3.ring.types.LaunchRing;
import me.fung.autop3.ring.types.LavaClipRing;
import me.fung.autop3.ring.types.MotionRing;
import me.fung.autop3.ring.types.RotateRing;
import me.fung.autop3.ring.types.StopRing;
import me.fung.autop3.ring.types.TntRing;
import me.fung.autop3.ring.types.WalkRing;
import me.fung.autop3.utils.Utils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommand;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;

public class AutoP3Command extends CommandBase implements ICommand {
    public String func_71517_b() {
        return "autop3";
    }

    public String func_71518_a(ICommandSender arg0) {
        return "/" + this.func_71517_b();
    }

    public int func_82362_a() {
        return 0;
    }

    public List<String> func_180525_a(ICommandSender sender, String[] args, BlockPos pos) {
        if (args.length == 1) {
            return func_71530_a(args, new String[]{"add", "remove", "set", "awaitterm", "loadconfig"});
        } else {
            if (args.length == 2) {
                String arg1 = args[0].toLowerCase();
                if (arg1.equals("add")) {
                    return func_71530_a(args, new String[]{"motion", "stop", "walk", "hclip", "rotate", "tnt", "jump", "launch", "command", "clip"});
                }

                if (arg1.equals("set")) {
                    return func_71530_a(args, new String[]{"position", "size"});
                }
            }

            return null;
        }
    }

    public void func_71515_b(ICommandSender sender, String[] args) {
        if (args.length == 0) {
            Utils.scheduleTask(0, () -> Minecraft.func_71410_x().func_147108_a(ConfigGui.INSTANCE.gui()));
        } else {
            EntityPlayerSP player = Minecraft.func_71410_x().field_71439_g;
            switch (args[0].toLowerCase()) {
                case "add":
                    try {
                        String type = args[1];
                        int extraArgs = 0;
                        RingType ring;
                        switch (type) {
                            case "motion":
                                double yaw = MathHelper.func_76138_g((double)player.field_70177_z);
                                ring = new MotionRing(yaw);
                                Utils.addChatMessage("Added Motion Ring (direction: " + (int)yaw + ")");
                                break;
                            case "walk":
                                double yaw = MathHelper.func_76138_g((double)player.field_70177_z);
                                ring = new WalkRing(yaw);
                                Utils.addChatMessage("Added Walk Ring (direction: " + (int)yaw + ")");
                                break;
                            case "stop":
                                ring = new StopRing();
                                Utils.addChatMessage("Added Stop Ring");
                                break;
                            case "hclip":
                                double yaw = MathHelper.func_76138_g((double)player.field_70177_z);
                                ring = new HClipRing(yaw);
                                Utils.addChatMessage("Added HClip Ring (direction: " + (int)yaw + ")");
                                break;
                            case "rotate":
                                double yaw = MathHelper.func_76138_g((double)player.field_70177_z);
                                double pitch = (double)player.field_70125_A;
                                ring = new RotateRing(yaw, pitch);
                                Utils.addChatMessage("Added Rotate Ring (Yaw: " + (int)yaw + ", Pitch: " + pitch + ")");
                                break;
                            case "tnt":
                                MovingObjectPosition mop = Minecraft.func_71410_x().field_71476_x;
                                if (mop == null || mop.field_72313_a != MovingObjectType.BLOCK) {
                                    Utils.addChatMessage("You need to aim at a block!");
                                    return;
                                }

                                BlockPos pos = mop.func_178782_a();
                                ring = new TntRing(pos);
                                Utils.addChatMessage("Added TNT Ring (Position: " + pos.func_177958_n() + ", " + pos.func_177956_o() + ", " + pos.func_177952_p() + ")");
                                break;
                            case "jump":
                                ring = new JumpRing();
                                Utils.addChatMessage("Added Jump Ring");
                                break;
                            case "launch":
                                if (args.length < 5) {
                                    Utils.addChatMessage("/autop3 add launch <motionY> <width> <height>");
                                    return;
                                }

                                ++extraArgs;
                                double motionY = Double.parseDouble(args[2]);
                                ring = new LaunchRing(motionY);
                                Utils.addChatMessage("Added Launch Ring");
                                break;
                            case "clip":
                                if (args.length < 5) {
                                    Utils.addChatMessage("/autop3 add clip <block> <width> <height>");
                                    return;
                                }

                                ++extraArgs;
                                double block = Double.parseDouble(args[2]);
                                ring = new LavaClipRing(block);
                                Utils.addChatMessage("Added Clip Ring");
                                break;
                            case "command":
                                if (args.length < 5) {
                                    Utils.addChatMessage("/autop3 add clip <command> <width> <height>");
                                    return;
                                }

                                extraArgs += args.length - 4;
                                String command = Utils.arrayToString(Utils.subStringArray(args, 2, args.length - 2));
                                ring = new CommandRing(command);
                                Utils.addChatMessage("Added Command Ring: " + command);
                                break;
                            default:
                                Utils.addChatMessage("Invalid ring type");
                                return;
                        }

                        double width = Double.parseDouble(args[extraArgs + 2]);
                        double height = Double.parseDouble(args[extraArgs + 3]);
                        ring.x = player.field_70165_t;
                        ring.y = player.field_70163_u;
                        ring.z = player.field_70161_v;
                        ring.width = width;
                        ring.height = height;
                        AutoP3Handler.deactivateRings.add(ring);
                        RingType.getCurrentPresetRings().add(ring);
                        RingType.save();
                    } catch (Exception var18) {
                        Utils.addChatMessage("Usage: /autop3 add <motion/stop/walk/hclip/rotate/tnt/jump/launch/clip/command> <width> <height>");
                    }
                    break;
                case "remove":
                    RingType ring = RingType.getRingAtCursor();
                    if (ring == null) {
                        Utils.addChatMessage("You need to aim at a ring to remove it!");
                        return;
                    }

                    RingType.getCurrentPresetRings().remove(ring);
                    RingType.save();
                    Utils.addChatMessage("Removed ring!");
                    break;
                case "edit":
                case "set":
                    RingType ring = RingType.getRingAtCursor();
                    if (args.length < 2) {
                        Utils.addChatMessage("Usage: /autop3 set <position/size>");
                        return;
                    }

                    if (ring == null) {
                        Utils.addChatMessage("You need to aim at a ring to set it!");
                        return;
                    }

                    switch (args[1].toLowerCase()) {
                        case "position":
                            if (args.length < 5) {
                                Utils.addChatMessage("Usage: /autop3 set position <x> <y> <z>");
                                return;
                            }

                            double z;
                            double x;
                            double y;
                            try {
                                x = Double.parseDouble(args[2]);
                                y = Double.parseDouble(args[3]);
                                z = Double.parseDouble(args[4]);
                            } catch (NumberFormatException var17) {
                                Utils.addChatMessage("Number only!");
                                return;
                            }

                            ring.x = x;
                            ring.y = y;
                            ring.z = z;
                            Utils.addChatMessage("Set ring new position to " + x + ", " + y + ", " + z);
                            break;
                        case "size":
                            if (args.length < 4) {
                                Utils.addChatMessage("Usage: /autop3 set size <width> <height>");
                                return;
                            }

                            double width;
                            double height;
                            try {
                                width = Double.parseDouble(args[2]);
                                height = Double.parseDouble(args[3]);
                            } catch (NumberFormatException var16) {
                                Utils.addChatMessage("Number only!");
                                return;
                            }

                            ring.width = width;
                            ring.height = height;
                            Utils.addChatMessage("Set ring new size to " + width + ", " + height);
                            break;
                        default:
                            Utils.addChatMessage("Usage: /autop3 set <position/size>");
                    }

                    RingType.save();
                    break;
                case "awaitterm":
                    RingType ring = RingType.getRingAtCursor();
                    if (ring == null) {
                        Utils.addChatMessage("Aim at a ring");
                        return;
                    }

                    ring.awaitTerm = !ring.awaitTerm;
                    RingType.save();
                    Utils.addChatMessage("Ring will " + (ring.awaitTerm ? "wait for terminal now" : "no longer wait for terminal"));
                    break;
                case "test":
                    player.field_70181_x = (double)0.42F;
                    break;
                case "loadconfig":
                    RingType.load();
                    Utils.addChatMessage("Loaded configs!");
                    break;
                default:
                    Utils.addChatMessage("Usage: /autop3 <add/remove/set/awaitterm/loadconfig>");
            }

        }
    }
}
