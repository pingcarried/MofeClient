package me.fung.autop3.command;

import java.util.List;
import me.fung.autop3.ConfigGui;
import me.fung.autop3.features.AutoP3Handler;
import me.fung.autop3.ring.RingType;
import me.fung.autop3.ring.types.*;
import me.fung.autop3.utils.Utils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommand;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;

public class AutoP3Command extends CommandBase implements ICommand {
    public String func_71517_b() {
        return "autop3";
    }

    public String func_71518_a(ICommandSender arg0) {
        return "/" + this.func_71517_b();
    }

    public int func_82362_a() {
        return 0;
    }

    public List<String> func_180525_a(ICommandSender sender, String[] args, BlockPos pos) {
        if (args.length == 1) {
            return func_71530_a(args, new String[]{"add", "remove", "set", "awaitterm", "loadconfig"});
        } else {
            if (args.length == 2) {
                String arg1 = args[0].toLowerCase();
                if (arg1.equals("add")) {
                    return func_71530_a(args, new String[]{"motion", "stop", "walk", "hclip", "rotate", "tnt", "jump", "launch", "command", "clip", "airwalk"});
                }

                if (arg1.equals("set")) {
                    return func_71530_a(args, new String[]{"position", "size"});
                }
            }

            return null;
        }
    }

    public void func_71515_b(ICommandSender sender, String[] args) {
        if (args.length == 0) {
            Utils.scheduleTask(0, () -> Minecraft.func_71410_x().func_147108_a(ConfigGui.INSTANCE.gui()));
        } else {
            EntityPlayerSP player = Minecraft.func_71410_x().field_71439_g;
            switch (args[0].toLowerCase()) {

                case "add":
                    try {
                        String type = args[1];
                        int extraArgs = 0;
                        RingType ring = null;
                        boolean hasDelay = false;
                        long delayMs = 0;

                        // Check for delay parameter
                        if (args.length >= 5 && args[args.length-2].equalsIgnoreCase("delay")) {
                            try {
                                delayMs = Long.parseLong(args[args.length-1]);
                                hasDelay = true;
                            } catch (NumberFormatException e) {
                                Utils.addChatMessage("Invalid delay value! Use milliseconds (e.g. 'delay 1000')");
                                return;
                            }
                        }

                        // Calculate base argument count (excluding delay)
                        int baseArgCount = hasDelay ? args.length - 2 : args.length;

                        switch (type.toLowerCase()) {
                            case "walk":
                                if (baseArgCount < 3) {
                                    Utils.addChatMessage("Usage: /autop3 add walk [delay <ms>] <width> <height>");
                                    return;
                                }
                                ring = new WalkRing();
                                Utils.addChatMessage("Added Walk Ring (Direction: " + (int)((WalkRing)ring).yaw + "°)");
                                break;

                            case "jump":
                                if (baseArgCount < 3) {
                                    Utils.addChatMessage("Usage: /autop3 add jump [delay <ms>] <width> <height>");
                                    return;
                                }
                                ring = new JumpRing();
                                Utils.addChatMessage("Added Jump Ring");
                                break;

                            case "stop":
                                if (baseArgCount < 3) {
                                    Utils.addChatMessage("Usage: /autop3 add stop [delay <ms>] <width> <height>");
                                    return;
                                }
                                ring = new StopRing();
                                Utils.addChatMessage("Added Stop Ring");
                                break;

                            case "hclip":
                                if (baseArgCount < 3) {
                                    Utils.addChatMessage("Usage: /autop3 add hclip [delay <ms>] <width> <height>");
                                    return;
                                }
                                ring = new HClipRing();
                                Utils.addChatMessage("Added HClip Ring (Direction: " + (int)((HClipRing)ring).yaw + "°)");
                                break;

                            case "rotate":
                                if (baseArgCount < 3) {
                                    Utils.addChatMessage("Usage: /autop3 add rotate [delay <ms>] <width> <height>");
                                    return;
                                }
                                ring = new RotateRing();
                                Utils.addChatMessage("Added Rotate Ring (Yaw: " + (int)((RotateRing)ring).yaw +
                                        ", Pitch: " + (int)((RotateRing)ring).pitch + ")");
                                break;

                            case "tnt":
                                if (baseArgCount < 3) {
                                    Utils.addChatMessage("Usage: /autop3 add tnt [delay <ms>] <width> <height>");
                                    return;
                                }
                                MovingObjectPosition mop = Minecraft.getMinecraft().objectMouseOver;
                                if (mop == null || mop.typeOfHit != MovingObjectPosition.MovingObjectType.BLOCK) {
                                    Utils.addChatMessage("You need to aim at a block!");
                                    return;
                                }
                                ring = new TntRing(mop.getBlockPos());
                                Utils.addChatMessage("Added TNT Ring at " + mop.getBlockPos());
                                break;

                            case "launch":
                                if (baseArgCount < 4) {
                                    Utils.addChatMessage("Usage: /autop3 add launch <motionY> [delay <ms>] <width> <height>");
                                    return;
                                }
                                try {
                                    double motionY = Double.parseDouble(args[2]);
                                    ring = new LaunchRing(motionY);
                                    extraArgs = 1;
                                    Utils.addChatMessage("Added Launch Ring (Power: " + motionY + ")");
                                } catch (NumberFormatException e) {
                                    Utils.addChatMessage("Invalid motionY! Use a number.");
                                    return;
                                }
                                break;

                            case "clip":
                                if (baseArgCount < 4) {
                                    Utils.addChatMessage("Usage: /autop3 add clip <block> [delay <ms>] <width> <height>");
                                    return;
                                }
                                try {
                                    double block = Double.parseDouble(args[2]);
                                    ring = new LavaClipRing(block);
                                    extraArgs = 1;
                                    Utils.addChatMessage("Added Clip Ring");
                                } catch (NumberFormatException e) {
                                    Utils.addChatMessage("Invalid block value! Use a number.");
                                    return;
                                }
                                break;

                            case "airwalk":
                                if (baseArgCount < 3) {
                                    Utils.addChatMessage("Usage: /autop3 add airwalk [delay <ms>] <width> <height>");
                                    return;
                                }
                                ring = new AirwalkRing();
                                Utils.addChatMessage("Added Airwalk Ring");
                                break;

                            case "command":
                                if (baseArgCount < 4) {
                                    Utils.addChatMessage("Usage: /autop3 add command <command> [delay <ms>] <width> <height>");
                                    return;
                                }
                                // Handle command string which may contain spaces
                                int commandEnd = hasDelay ? args.length - 3 : args.length - 2;
                                String command = String.join(" ", Arrays.copyOfRange(args, 2, commandEnd));
                                ring = new CommandRing(command);
                                extraArgs = command.split(" ").length - 1;
                                Utils.addChatMessage("Added Command Ring: " + command);
                                break;

                            default:
                                Utils.addChatMessage("Invalid ring type. Valid types: walk, jump, stop, hclip, rotate, tnt, launch, clip, command");
                                return;
                        }

                        if (ring != null) {
                            // Set delay if specified
                            if (hasDelay) {
                                ring.setDelay(delayMs);
                            }

                            // Parse width and height
                            int widthIndex = 2 + extraArgs + (hasDelay ? 0 : 0);
                            int heightIndex = widthIndex + 1;

                            try {
                                ring.width = Double.parseDouble(args[widthIndex]);
                                ring.height = Double.parseDouble(args[heightIndex]);

                                // Set position to player's current location
                                EntityPlayerSP player = Minecraft.getMinecraft().thePlayer;
                                ring.x = player.posX;
                                ring.y = player.posY;
                                ring.z = player.posZ;

                                // Add to handler and save
                                AutoP3Handler.deactivateRings.add(ring);
                                RingType.getCurrentPresetRings().add(ring);
                                RingType.save();

                                if (hasDelay) {
                                    Utils.addChatMessage("Delay set to " + delayMs + "ms");
                                }
                            } catch (NumberFormatException e) {
                                Utils.addChatMessage("Invalid width/height! Use numbers.");
                            }
                        }
                    } catch (Exception e) {
                        Utils.addChatMessage("Error: " + e.getMessage());
                        e.printStackTrace();
                        Utils.addChatMessage("General usage: /autop3 add <type> [params] [delay <ms>] <width> <height>");
                    }
                    break;
                case "remove":
                    RingType ring = RingType.getRingAtCursor();
                    if (ring == null) {
                        Utils.addChatMessage("You need to aim at a ring to remove it!");
                        return;
                    }

                    RingType.getCurrentPresetRings().remove(ring);
                    RingType.save();
                    Utils.addChatMessage("Removed ring!");
                    break;
                case "edit":
                case "set":
                    RingType ring = RingType.getRingAtCursor();
                    if (args.length < 2) {
                        Utils.addChatMessage("Usage: /autop3 set <position/size>");
                        return;
                    }

                    if (ring == null) {
                        Utils.addChatMessage("You need to aim at a ring to set it!");
                        return;
                    }

                    switch (args[1].toLowerCase()) {
                        case "position":
                            if (args.length < 5) {
                                Utils.addChatMessage("Usage: /autop3 set position <x> <y> <z>");
                                return;
                            }

                            double z;
                            double x;
                            double y;
                            try {
                                x = Double.parseDouble(args[2]);
                                y = Double.parseDouble(args[3]);
                                z = Double.parseDouble(args[4]);
                            } catch (NumberFormatException var17) {
                                Utils.addChatMessage("Number only!");
                                return;
                            }

                            ring.x = x;
                            ring.y = y;
                            ring.z = z;
                            Utils.addChatMessage("Set ring new position to " + x + ", " + y + ", " + z);
                            break;
                        case "size":
                            if (args.length < 4) {
                                Utils.addChatMessage("Usage: /autop3 set size <width> <height>");
                                return;
                            }

                            double width;
                            double height;
                            try {
                                width = Double.parseDouble(args[2]);
                                height = Double.parseDouble(args[3]);
                            } catch (NumberFormatException var16) {
                                Utils.addChatMessage("Number only!");
                                return;
                            }

                            ring.width = width;
                            ring.height = height;
                            Utils.addChatMessage("Set ring new size to " + width + ", " + height);
                            break;
                        default:
                            Utils.addChatMessage("Usage: /autop3 set <position/size>");
                    }

                    RingType.save();
                    break;
                case "awaitterm":
                    RingType ring = RingType.getRingAtCursor();
                    if (ring == null) {
                        Utils.addChatMessage("Aim at a ring");
                        return;
                    }

                    ring.awaitTerm = !ring.awaitTerm;
                    RingType.save();
                    Utils.addChatMessage("Ring will " + (ring.awaitTerm ? "wait for terminal now" : "no longer wait for terminal"));
                    break;
                case "test":
                    player.field_70181_x = (double)0.42F;
                    break;
                case "loadconfig":
                    RingType.load();
                    Utils.addChatMessage("Loaded configs!");
                    break;
                default:
                    Utils.addChatMessage("Usage: /autop3 <add/remove/set/awaitterm/loadconfig>");
            }

        }
    }
}
