//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3;

import me.fung.autop3.command.AutoP3Command;
import me.fung.autop3.events.ChatEvent;
import me.fung.autop3.events.GuiChestEvent;
import me.fung.autop3.events.RenderOverlayEvent;
import me.fung.autop3.events.TickStartEvent;
import me.fung.autop3.features.AutoP3Handler;
import me.fung.autop3.features.FeatureHandler;
import me.fung.autop3.features.LavaClipHandler;
import me.fung.autop3.features.MotionHandler;
import me.fung.autop3.features.PacketHandler;
import me.fung.autop3.utils.Utils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.inventory.GuiChest;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ContainerChest;
import net.minecraft.util.StringUtils;
import net.minecraftforge.client.ClientCommandHandler;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.client.event.GuiScreenEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent.ElementType;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.Phase;
import net.minecraftforge.fml.common.network.FMLNetworkEvent;

@Mod(
        modid = "Spotify Player",
        name = "Kaze's Auto P3",
        version = "1.0.1",
        acceptedMinecraftVersions = "[1.8.9]"
)
public class Main {
    public static final String MOD_NAME = "Kaze's Auto P3";
    public static final String MODID = "Spotify Player";
    public static final String VERSION = "1.0.1";
    public static final Minecraft mc = Minecraft.func_71410_x();
    public static Main INSTANCE;
    public static int tickAmount = 0;

    public Main() {
        INSTANCE = this;
    }

    @EventHandler
    public void preInit(FMLPreInitializationEvent event) {
    }

    @EventHandler
    public void init(FMLInitializationEvent event) {
        ClientCommandHandler.instance.func_71560_a(new AutoP3Command());
        MinecraftForge.EVENT_BUS.register(this);
        MinecraftForge.EVENT_BUS.register(new AutoP3Handler());
        MinecraftForge.EVENT_BUS.register(new Utils());
        MinecraftForge.EVENT_BUS.register(MotionHandler.INSTANCE);
        MinecraftForge.EVENT_BUS.register(LavaClipHandler.INSTANCE);
        MinecraftForge.EVENT_BUS.register(new FeatureHandler());
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase == Phase.START) {
            ++tickAmount;
            MinecraftForge.EVENT_BUS.post(new TickStartEvent());
            if (!Utils.messageQueue.isEmpty()) {
                String message = (String)Utils.messageQueue.remove(0);
                mc.field_71439_g.func_71165_d(message);
            }

        }
    }

    @SubscribeEvent
    public void onServerConnect(FMLNetworkEvent.ClientConnectedToServerEvent event) {
        event.manager.channel().pipeline().addBefore("packet_handler", "kaze_autop3_packet_handler", new PacketHandler());
    }

    @SubscribeEvent
    public void onGuiRender(GuiScreenEvent.BackgroundDrawnEvent event) {
        if (event.gui instanceof GuiChest) {
            GuiChest inventory = (GuiChest)event.gui;
            Container containerChest = inventory.field_147002_h;
            if (containerChest instanceof ContainerChest) {
                MinecraftForge.EVENT_BUS.post(new GuiChestEvent(inventory, ((ContainerChest)containerChest).func_85151_d().func_145748_c_().func_150260_c().trim(), inventory.field_147002_h.field_75151_b, event.getMouseX(), event.getMouseY()));
            }
        }

    }

    @SubscribeEvent(
            priority = EventPriority.HIGHEST
    )
    public void onChat(ClientChatReceivedEvent event) {
        if (event.type == 0) {
            String message = StringUtils.func_76338_a(event.message.func_150260_c());
            MinecraftForge.EVENT_BUS.post(new ChatEvent(message, event.message));
            int index = message.indexOf(": ");
            if (index != -1) {
                String msg = message.substring(index + 2);
                if (message.startsWith("Party > ")) {
                    String sender = Utils.removeRank(message.substring(8, message.indexOf(":")));
                    if (msg.startsWith("!")) {
                        msg = msg.substring(1);
                        String command = msg;
                        String[] arg = new String[0];
                        if (msg.contains(" ")) {
                            command = msg.split(" ")[0];
                            arg = msg.replaceFirst(command + " ", "").split(" ");
                        }

                        ChatEvent.PartyCommand chatEvent = new ChatEvent.PartyCommand(command.toLowerCase(), sender, arg);
                        MinecraftForge.EVENT_BUS.post(chatEvent);
                        if (chatEvent.isCanceled()) {
                            event.setCanceled(true);
                        }
                    } else {
                        ChatEvent.PartyChat chatEvent = new ChatEvent.PartyChat(msg.toLowerCase(), sender);
                        MinecraftForge.EVENT_BUS.post(chatEvent);
                        if (chatEvent.isCanceled()) {
                            event.setCanceled(true);
                        }
                    }
                }

                if (message.startsWith("From ")) {
                    String sender = Utils.removeRank(message.substring(5, message.indexOf(":")));
                    if (msg.startsWith("!")) {
                        msg = msg.substring(1);
                        String command = msg;
                        String[] arg = new String[0];
                        if (msg.contains(" ")) {
                            command = msg.split(" ")[0];
                            arg = msg.replaceFirst(command + " ", "").split(" ");
                        }

                        if (MinecraftForge.EVENT_BUS.post(new ChatEvent.PrivateChatCommand(command.toLowerCase(), sender, arg))) {
                            event.setCanceled(true);
                        }
                    }
                }

            }
        }
    }

    @SubscribeEvent
    public void onWorldChange(WorldEvent.Unload event) {
    }

    @SubscribeEvent
    public void renderPlayerInfo(RenderGameOverlayEvent.Post event) {
        if (event.type == ElementType.EXPERIENCE || event.type == ElementType.JUMPBAR) {
            MinecraftForge.EVENT_BUS.post(new RenderOverlayEvent());
        }
    }
}
