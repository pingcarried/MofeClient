//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3.features;

import java.awt.Color;
import java.util.ArrayList;
import java.util.WeakHashMap;
import me.fung.autop3.ConfigGui;
import me.fung.autop3.Preset;
import me.fung.autop3.events.TickStartEvent;
import me.fung.autop3.ring.RingType;
import me.fung.autop3.utils.PlayerUtils;
import me.fung.autop3.utils.RenderUtils;
import me.fung.autop3.utils.Utils;
import net.minecraft.block.Block;
import net.minecraft.block.BlockRailBase;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.entity.Entity;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.Vec3;
import net.minecraft.world.WorldSettings;
import net.minecraft.world.WorldSettings.GameType;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

public class FeatureHandler {
    private static final ArrayList<Vec3> trailers = new ArrayList();
    private static final WeakHashMap<Entity, Long> cryptGhoulHitMap = new WeakHashMap();
    private static boolean switchGamemode;
    private static WorldSettings.GameType prevGamemode;
    private BlockPos prevPos;

    @SubscribeEvent
    public void onTickStart(TickStartEvent event) {
        Minecraft mc = Minecraft.func_71410_x();
        EntityPlayerSP player = mc.field_71439_g;
        if (player != null && mc.field_71441_e != null) {
            long current = System.currentTimeMillis();
            if (ConfigGui.INSTANCE.toggleSprint) {
                Utils.setKeyBindState(mc.field_71474_y.field_151444_V, true);
            }

            if (ConfigGui.INSTANCE.trailer) {
                if (player.field_70165_t != player.field_70142_S || player.field_70163_u != player.field_70137_T || player.field_70161_v != player.field_70136_U) {
                    trailers.add(new Vec3(player.field_70165_t, player.field_70163_u, player.field_70161_v));
                }

                if (trailers.size() > ConfigGui.INSTANCE.trailerLength * 10) {
                    trailers.remove(0);
                }
            } else {
                trailers.clear();
            }

            if (ConfigGui.INSTANCE.gameModeSwitch) {
                NetworkPlayerInfo playerInfo = mc.func_147114_u().func_175102_a(mc.field_71439_g.func_110124_au());
                if (playerInfo != null) {
                    WorldSettings.GameType gameMode = playerInfo.func_178848_b();
                    if (gameMode != GameType.SPECTATOR) {
                        prevGamemode = gameMode;
                    }

                    if (Keyboard.isKeyDown(61) && Keyboard.isKeyDown(49)) {
                        if (!switchGamemode) {
                            switchGamemode = true;
                            Utils.sendMessage("/gamemode " + (gameMode == GameType.SPECTATOR ? prevGamemode.func_77148_a() : 3));
                        }
                    } else {
                        switchGamemode = false;
                    }
                }
            }

            int currentConfig = ConfigGui.INSTANCE.configMode;
            if (currentConfig != RingType.lastSavedType) {
                RingType.lastSavedType = currentConfig;
                Preset.currentPreset = Preset.values()[currentConfig];
                Utils.addChatMessage("Loading §3" + Preset.currentPreset.name() + " §fpreset!");
                RingType.load();
            }

            if (ConfigGui.INSTANCE.cryptGhoulAura) {
                for(Entity entity : mc.field_71441_e.field_72996_f) {
                    if (entity instanceof EntityZombie && !(player.func_70032_d(entity) > 3.0F)) {
                        EntityZombie zombie = (EntityZombie)entity;
                        Long time = (Long)cryptGhoulHitMap.get(entity);
                        if (time == null || time >= current + 2000L) {
                            ItemStack chestplate = zombie.func_82169_q(2);
                            if (chestplate != null && chestplate.func_77973_b() == Items.field_151023_V) {
                                mc.field_71439_g.func_71038_i();
                                mc.field_71442_b.func_78764_a(mc.field_71439_g, entity);
                                cryptGhoulHitMap.put(zombie, current);
                            }
                        }
                    }
                }
            }

            if (ConfigGui.INSTANCE.lavaSimulator) {
                ServerData currentServer = mc.func_147104_D();
                if (mc.func_71356_B() || currentServer != null && "localhost".equals(currentServer.field_78845_b)) {
                    NetworkPlayerInfo playerInfo = mc.func_147114_u().func_175102_a(mc.field_71439_g.func_110124_au());
                    if (playerInfo != null) {
                        WorldSettings.GameType gameMode = playerInfo.func_178848_b();
                        if (gameMode != GameType.SPECTATOR) {
                            BlockPos playerPos = PlayerUtils.getPlayerPos();
                            Block block = mc.field_71441_e.func_180495_p(playerPos).func_177230_c();
                            if (block instanceof BlockRailBase || mc.field_71439_g.func_180799_ab()) {
                                Utils.scheduleTask(0, this::lavaJump);
                                if (block instanceof BlockRailBase) {
                                    Utils.scheduleTask(1, this::lavaJump);
                                }
                            }
                        }
                    }
                }
            }

        }
    }

    @SubscribeEvent
    public void onWorldRender(RenderWorldLastEvent event) {
        if (trailers.size() > 1) {
            int size = trailers.size() - 1;

            for(int i = 0; i < size; ++i) {
                double progress = (double)i / (double)size;
                Vec3 node = (Vec3)trailers.get(i);
                Vec3 nextNode = (Vec3)trailers.get(i + 1);
                Color color = new Color((int)((double)220.0F - (double)150.0F * progress), (int)((double)220.0F - (double)150.0F * progress), 255);
                RenderUtils.drawLine(node, nextNode, color, 2.0F, true);
            }
        }

    }

    @SubscribeEvent
    public void onWorldUnload(WorldEvent.Unload event) {
        trailers.clear();
    }

    private void lavaJump() {
        Minecraft.func_71410_x().field_71439_g.field_70181_x = AutoP3Handler.nextLaunchY == (double)-1.0F ? (double)3.5F : AutoP3Handler.nextLaunchY;
        if (AutoP3Handler.nextLaunchY != (double)-1.0F) {
            Utils.addChatMessage("Launch!");
            AutoP3Handler.nextLaunchY = (double)-1.0F;
        }

    }

    static {
        prevGamemode = GameType.CREATIVE;
    }
}
