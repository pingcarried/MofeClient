//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3.features;

import me.fung.autop3.ConfigGui;
import me.fung.autop3.events.PacketReceivedEvent;
import me.fung.autop3.utils.PlayerUtils;
import me.fung.autop3.utils.Utils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.util.MathHelper;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.Phase;
import org.lwjgl.input.Keyboard;

public class MotionHandler {
    public static final MotionHandler INSTANCE = new MotionHandler();
    public boolean motioning;
    public boolean prevForward;
    public boolean prevLeft;
    public boolean prevRight;
    public boolean prevBackward;
    public boolean prevSneak;
    private int motionTick;
    private double yaw;
    public static long lastTeleportPacketTime;

    public static boolean motion(double yaw) {
        EntityPlayerSP player = Minecraft.func_71410_x().field_71439_g;
        player.field_70159_w = (double)0.0F;
        player.field_70179_y = (double)0.0F;
        INSTANCE.motioning = false;
        long current = System.currentTimeMillis();
        if (lastTeleportPacketTime + 3000L > current) {
            return false;
        } else if (!player.field_70122_E) {
            return false;
        } else {
            Utils.addChatMessage("Motion");
            INSTANCE.yaw = yaw;
            INSTANCE.motioning = true;
            INSTANCE.motionTick = 0;
            Utils.setKeyBindState(Minecraft.func_71410_x().field_71474_y.field_74311_E, false);

            for(KeyBinding keyBind : PlayerUtils.MOVEMENT_KEYS) {
                Utils.setKeyBindState(keyBind, false);
            }

            INSTANCE.prevForward = Keyboard.isKeyDown(Minecraft.func_71410_x().field_71474_y.field_74351_w.func_151463_i());
            INSTANCE.prevLeft = Keyboard.isKeyDown(Minecraft.func_71410_x().field_71474_y.field_74370_x.func_151463_i());
            INSTANCE.prevRight = Keyboard.isKeyDown(Minecraft.func_71410_x().field_71474_y.field_74366_z.func_151463_i());
            INSTANCE.prevBackward = Keyboard.isKeyDown(Minecraft.func_71410_x().field_71474_y.field_74368_y.func_151463_i());
            INSTANCE.prevSneak = Keyboard.isKeyDown(Minecraft.func_71410_x().field_71474_y.field_74311_E.func_151463_i());
            return true;
        }
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        EntityPlayerSP player = Minecraft.func_71410_x().field_71439_g;
        if (event.player == player) {
            Minecraft mc = Minecraft.func_71410_x();
            if (event.phase == Phase.START) {
                boolean forward = Keyboard.isKeyDown(mc.field_71474_y.field_74351_w.func_151463_i());
                boolean left = Keyboard.isKeyDown(mc.field_71474_y.field_74370_x.func_151463_i());
                boolean right = Keyboard.isKeyDown(mc.field_71474_y.field_74366_z.func_151463_i());
                boolean backward = Keyboard.isKeyDown(mc.field_71474_y.field_74368_y.func_151463_i());
                boolean sneak = Keyboard.isKeyDown(mc.field_71474_y.field_74311_E.func_151463_i());
                if (this.motioning && (!this.prevForward && forward || !this.prevLeft && left || !this.prevRight && right || !this.prevBackward && backward || !this.prevSneak && sneak)) {
                    this.motioning = false;
                    Utils.addChatMessage("Stop motion");
                    return;
                }

                if (!this.motioning) {
                    return;
                }

                if (player.func_180799_ab()) {
                    this.motioning = false;
                    return;
                }
            }

        }
    }

    public static void walk(double yaw) {
        Utils.scheduleTask(0, () -> {
            Utils.setKeyBindState(Minecraft.func_71410_x().field_71474_y.field_74311_E, false);

            for(KeyBinding keyBind : PlayerUtils.MOVEMENT_KEYS) {
                Utils.setKeyBindState(keyBind, false);
            }

            INSTANCE.yaw = yaw;
            INSTANCE.motioning = true;
            INSTANCE.motionTick = 5;
            INSTANCE.prevForward = Keyboard.isKeyDown(Minecraft.func_71410_x().field_71474_y.field_74351_w.func_151463_i());
            INSTANCE.prevLeft = Keyboard.isKeyDown(Minecraft.func_71410_x().field_71474_y.field_74370_x.func_151463_i());
            INSTANCE.prevRight = Keyboard.isKeyDown(Minecraft.func_71410_x().field_71474_y.field_74366_z.func_151463_i());
            INSTANCE.prevBackward = Keyboard.isKeyDown(Minecraft.func_71410_x().field_71474_y.field_74368_y.func_151463_i());
            INSTANCE.prevSneak = Keyboard.isKeyDown(Minecraft.func_71410_x().field_71474_y.field_74368_y.func_151463_i());
        });
    }

    public boolean moveEntityWithHeading(float a, float b) {
        if (this.motioning) {
            EntityPlayerSP player = Minecraft.func_71410_x().field_71439_g;
            if (this.motionTick == 0) {
                double speed = (double)player.field_71075_bZ.func_75094_b() * 0.1;
                player.field_70159_w = Math.sin(this.yaw * Math.PI / (double)180.0F) * speed;
                player.field_70179_y = -Math.cos(this.yaw * Math.PI / (double)180.0F) * speed;
            }

            if (this.motionTick == 1) {
                player.func_70664_aZ();
                double speed = (double)(player.field_71075_bZ.func_75094_b() * ConfigGui.INSTANCE.motionStrength);
                player.field_70159_w = -Math.sin(this.yaw * Math.PI / (double)180.0F) * speed;
                player.field_70179_y = Math.cos(this.yaw * Math.PI / (double)180.0F) * speed;
            }

            if (this.motionTick == 2) {
                player.field_70159_w *= (double)ConfigGui.INSTANCE.secondTickMultiplier;
                player.field_70179_y *= (double)ConfigGui.INSTANCE.secondTickMultiplier;
            }

            if (this.motionTick > 1) {
                if (player.field_70122_E) {
                    double speed = (double)player.field_71075_bZ.func_75094_b() * 2.8;
                    player.field_70159_w = -Math.sin(this.yaw * Math.PI / (double)180.0F) * speed;
                    player.field_70179_y = Math.cos(this.yaw * Math.PI / (double)180.0F) * speed;
                } else {
                    double drag = 0.91;
                    player.field_70159_w *= drag;
                    player.field_70179_y *= drag;
                }
            }

            player.func_70091_d(player.field_70159_w, player.field_70181_x, player.field_70179_y);
            ++this.motionTick;
            player.field_70181_x -= 0.08;
            player.field_70181_x *= (double)0.98F;
            player.field_70722_aY = player.field_70721_aZ;
            double d0 = player.field_70165_t - player.field_70169_q;
            double d3 = player.field_70161_v - player.field_70166_s;
            float f3 = MathHelper.func_76133_a(d0 * d0 + d3 * d3) * 4.0F;
            if (f3 > 1.0F) {
                f3 = 1.0F;
            }

            player.field_70721_aZ += (f3 - player.field_70721_aZ) * 0.4F;
            player.field_70754_ba += player.field_70721_aZ;
            return false;
        } else {
            return true;
        }
    }

    @SubscribeEvent
    public void onPacketReceived(PacketReceivedEvent event) {
        if (event.packet instanceof S08PacketPlayerPosLook && this.motioning) {
            lastTeleportPacketTime = System.currentTimeMillis();
            this.motioning = false;
            Utils.addChatMessage("Lag back detected. Disabling motion");
        }

    }
}
