//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3.features;

import io.netty.channel.ChannelDuplexHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelPromise;
import me.fung.autop3.events.PacketReceivedEvent;
import me.fung.autop3.events.PacketSentEvent;
import me.fung.autop3.utils.PacketUtils;
import net.minecraft.network.Packet;
import net.minecraftforge.common.MinecraftForge;

public class PacketHandler extends ChannelDuplexHandler {
    public void write(ChannelHandlerContext ctx, Object object, ChannelPromise promise) throws Exception {
        if (object instanceof Packet) {
            Packet<?> packet = (Packet)object;
            if (PacketUtils.packets.contains(packet)) {
                PacketUtils.packets.remove(packet);
            } else {
                if (!MinecraftForge.EVENT_BUS.post(new PacketSentEvent(packet, ctx))) {
                    super.write(ctx, object, promise);
                }

            }
        }
    }

    public void channelRead(ChannelHandlerContext ctx, Object object) throws Exception {
        if (!(object instanceof Packet) || !MinecraftForge.EVENT_BUS.post(new PacketReceivedEvent((Packet)object, ctx))) {
            super.channelRead(ctx, object);
        }
    }
}
