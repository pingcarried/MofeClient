//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3.features;

import me.fung.autop3.events.PacketReceivedEvent;
import me.fung.autop3.events.TickStartEvent;
import me.fung.autop3.utils.Utils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class LavaClipHandler {
    public static final LavaClipHandler INSTANCE = new LavaClipHandler();
    private boolean clipping;
    private boolean veloPacket;
    private double block;

    public static void clip(double block) {
        INSTANCE.clipping = true;
        INSTANCE.block = Math.abs(block);
    }

    @SubscribeEvent
    public void onTick(TickStartEvent event) {
        if (!Utils.isInGame()) {
            this.clipping = false;
        } else {
            Minecraft mc = Minecraft.func_71410_x();
            if (this.clipping && mc.field_71439_g.func_180799_ab()) {
                ServerData currentServer = mc.func_147104_D();
                if (!mc.func_71356_B() && !"localhost".equals(currentServer.field_78845_b)) {
                    this.veloPacket = true;
                } else {
                    Utils.addChatMessage("Clipped (Single player)");
                    this.clipping = false;
                }

                mc.field_71439_g.func_70107_b(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u - this.block, mc.field_71439_g.field_70161_v);
            }
        }
    }

    @SubscribeEvent
    public void onPacketReceived(PacketReceivedEvent event) {
        if (event.packet instanceof S12PacketEntityVelocity && this.veloPacket) {
            Minecraft mc = Minecraft.func_71410_x();
            S12PacketEntityVelocity packet = (S12PacketEntityVelocity)event.packet;
            if (mc.field_71439_g.func_145782_y() != packet.func_149412_c()) {
                return;
            }

            if (packet.func_149410_e() != 28000) {
                return;
            }

            event.setCanceled(true);
            this.veloPacket = false;
            this.clipping = false;
            Utils.addChatMessage("Clipped");
        }

    }
}
