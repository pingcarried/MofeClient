//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3;

public enum Preset {
    Default("default"),
    Archer("archer"),
    Berserk("berserk"),
    Healer("healer"),
    Mage("mage"),
    Tank("tank");

    public static Preset currentPreset;
    public final String presetName;

    private Preset(String presetName) {
        this.presetName = presetName;
    }

    public static Preset getCurrentPreset() {
        return currentPreset;
    }
}
