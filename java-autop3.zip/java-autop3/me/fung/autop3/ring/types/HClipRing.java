package me.fung.autop3.ring.types;

import com.google.gson.JsonObject;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.util.BlockPos;

public class HClipRing extends RingType {
    public double yaw;

    public HClipRing(double yaw) {
        this.yaw = yaw;
    }

    public HClipRing(JsonObject json) {
        super(json);
        this.yaw = json.get("yaw").getAsDouble();
    }

    @Override
    protected boolean execute() {
        double rad = Math.toRadians(this.yaw);
        double moveX = -Math.sin(rad) * 0.5;
        double moveZ = Math.cos(rad) * 0.5;

        Minecraft.getMinecraft().thePlayer.setPosition(
                Minecraft.getMinecraft().thePlayer.posX + moveX,
                Minecraft.getMinecraft().thePlayer.posY,
                Minecraft.getMinecraft().thePlayer.posZ + moveZ
        );
        return true;
    }

    @Override
    public JsonObject toJson() {
        JsonObject json = super.toJson();
        json.addProperty("type", "hclip");
        json.addProperty("yaw", this.yaw);
        return json;
    }

    @Override
    public Color getRingColor() {
        return new Color(100, 200, 200); // Cyan
    }

    public BlockPos getBlockPos() {
        return new BlockPos(this.x, this.y, this.z);
    }
}