package me.fung.autop3.ring.types;

import com.google.gson.JsonObject;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.util.BlockPos;

public class RotateRing extends RingType {
    public double yaw, pitch;

    public RotateRing(double yaw, double pitch) {
        this.yaw = yaw;
        this.pitch = pitch;
    }

    public RotateRing(JsonObject json) {
        super(json);
        this.yaw = json.get("yaw").getAsDouble();
        this.pitch = json.get("pitch").getAsDouble();
    }

    @Override
    protected boolean execute() {
        Minecraft.getMinecraft().thePlayer.rotationYaw = (float)this.yaw;
        Minecraft.getMinecraft().thePlayer.rotationPitch = (float)this.pitch;
        return true;
    }

    @Override
    public JsonObject toJson() {
        JsonObject json = super.toJson();
        json.addProperty("type", "rotate");
        json.addProperty("yaw", this.yaw);
        json.addProperty("pitch", this.pitch);
        return json;
    }

    @Override
    public Color getRingColor() {
        return new Color(150, 0, 150);
    }

    public BlockPos getBlockPos() {
        return new BlockPos(this.x, this.y, this.z);
    }
}