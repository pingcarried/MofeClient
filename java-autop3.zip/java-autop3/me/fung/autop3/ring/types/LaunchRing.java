package me.fung.autop3.ring.types;

import com.google.gson.JsonObject;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.util.BlockPos;

public class LaunchRing extends RingType {
    public double motionY;

    public LaunchRing(double motionY) {
        this.motionY = motionY;
    }

    public LaunchRing(JsonObject json) {
        super(json);
        this.motionY = json.get("motionY").getAsDouble();
    }

    @Override
    protected boolean execute() {
        Minecraft.getMinecraft().thePlayer.motionY = this.motionY;
        return true;
    }

    @Override
    public JsonObject toJson() {
        JsonObject json = super.toJson();
        json.addProperty("type", "launch");
        json.addProperty("motionY", this.motionY);
        return json;
    }

    @Override
    public Color getRingColor() {
        return new Color(255, 200, 0);
    }

    public BlockPos getBlockPos() {
        return new BlockPos(this.x, this.y, this.z);
    }
}