package me.fung.autop3.ring.types;

import com.google.gson.JsonObject;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.util.BlockPos;

public class AirwalkRing extends RingType {

    public AirwalkRing() {
        // Constructor for new rings
    }

    public AirwalkRing(JsonObject json) {
        super(json);
        // Constructor for loading from saved rings
    }

    @Override
    protected boolean execute() {
        // Simulate W key press
        KeyBinding.setKeyBindState(
                Minecraft.getMinecraft().gameSettings.keyBindForward.getKeyCode(),
                true
        );
        return true;
    }

    @Override
    public void onDeactivate() {
        // Release W key when leaving ring
        KeyBinding.setKeyBindState(
                Minecraft.getMinecraft().gameSettings.keyBindForward.getKeyCode(),
                false
        );
    }

    @Override
    public JsonObject toJson() {
        JsonObject json = super.toJson();
        json.addProperty("type", "airwalk");
        return json;
    }

    @Override
    public Color getRingColor() {
        return new Color(100, 200, 255); // Light blue
    }
}