package me.fung.autop3.ring.types;

import com.google.gson.JsonObject;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.util.BlockPos;

public class StopRing extends RingType {
    public StopRing() {}

    public StopRing(JsonObject json) {
        super(json);
    }

    @Override
    protected boolean execute() {
        Minecraft.getMinecraft().thePlayer.motionX = 0;
        Minecraft.getMinecraft().thePlayer.motionZ = 0;
        return true;
    }

    @Override
    public JsonObject toJson() {
        JsonObject json = super.toJson();
        json.addProperty("type", "stop");
        return json;
    }

    @Override
    public Color getRingColor() {
        return new Color(255, 50, 50);
    }

    public BlockPos getBlockPos() {
        return new BlockPos(this.x, this.y, this.z);
    }
}