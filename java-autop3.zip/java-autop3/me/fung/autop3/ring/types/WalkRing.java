package me.fung.autop3.ring.types;

import com.google.gson.JsonObject;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.util.BlockPos;

public class WalkRing extends RingType {
    public double yaw;

    // Constructor for new rings (auto-sets direction to player's look)
    public WalkRing() {
        this.yaw = Minecraft.getMinecraft().thePlayer.rotationYaw;
    }

    // Constructor for loading from JSON
    public WalkRing(JsonObject json) {
        super(json);
        this.yaw = json.get("yaw").getAsDouble();
    }

    @Override
    protected boolean execute() {
        Minecraft.getMinecraft().thePlayer.movementInput.moveForward = 1.0f;
        Minecraft.getMinecraft().thePlayer.rotationYaw = (float)this.yaw;
        return true;
    }

    @Override
    public JsonObject toJson() {
        JsonObject json = super.toJson();
        json.addProperty("type", "walk");
        json.addProperty("yaw", this.yaw);
        return json;
    }

    @Override
    public Color getRingColor() {
        return new Color(0, 200, 0); // Green
    }
}