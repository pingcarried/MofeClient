package me.fung.autop3.ring.types;

import com.google.gson.JsonObject;
import java.awt.Color;
import me.fung.autop3.ConfigGui;
import me.fung.autop3.ring.RingType;
import me.fung.autop3.utils.Utils;
import net.minecraft.client.Minecraft;
import net.minecraft.util.BlockPos;

public class CommandRing extends RingType {
    public String command;

    // Constructor for new rings
    public CommandRing(String command) {
        this.command = command;
    }

    // Constructor for loading from JSON
    public CommandRing(JsonObject json) {
        super(json);
        this.command = json.get("command").getAsString();
        this.x = json.get("x").getAsDouble();
        this.y = json.get("y").getAsDouble();
        this.z = json.get("z").getAsDouble();
        this.width = json.get("width").getAsDouble();
        this.height = json.get("height").getAsDouble();
        if (json.has("delay_ms")) {
            this.setDelay(json.get("delay_ms").getAsLong());
        }
        if (json.has("awaitTerm")) {
            this.awaitTerm = true;
        }
    }

    @Override
    protected boolean execute() {
        // Original command execution logic
        if (command.startsWith("/")) {
            Minecraft.getMinecraft().thePlayer.sendChatMessage(command);
        } else {
            Utils.sendMessage(command);
        }
        return true;
    }

    @Override
    public JsonObject toJson() {
        JsonObject json = super.toJson();
        json.addProperty("type", "command");
        json.addProperty("command", this.command);

        // Original serialization fields
        json.addProperty("x", this.x);
        json.addProperty("y", this.y);
        json.addProperty("z", this.z);
        json.addProperty("width", this.width);
        json.addProperty("height", this.height);

        // New delay support
        if (this.getDelay() > 0) {
            json.addProperty("delay_ms", this.getDelay());
        }
        if (this.awaitTerm) {
            json.addProperty("awaitTerm", true);
        }

        return json;
    }

    @Override
    public Color getRingColor() {
        return ConfigGui.INSTANCE.commandRingColor;
    }

    // Original validation method
    public boolean isValidCommand() {
        return this.command != null && !this.command.trim().isEmpty();
    }

    // Original position helper
    public BlockPos getBlockPos() {
        return new BlockPos(this.x, this.y, this.z);
    }
}