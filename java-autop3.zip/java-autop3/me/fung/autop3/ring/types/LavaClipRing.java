package me.fung.autop3.ring.types;

import com.google.gson.JsonObject;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.util.BlockPos;

public class LavaClipRing extends RingType {
    public double factor;

    public LavaClipRing(double factor) {
        this.factor = factor;
    }

    public LavaClipRing(JsonObject json) {
        super(json);
        this.factor = json.get("block").getAsDouble();
    }

    @Override
    protected boolean execute() {
        // Original lava clip logic
        Minecraft.getMinecraft().thePlayer.setPosition(
                Minecraft.getMinecraft().thePlayer.posX,
                Minecraft.getMinecraft().thePlayer.posY - this.factor,
                Minecraft.getMinecraft().thePlayer.posZ
        );
        return true;
    }

    @Override
    public JsonObject toJson() {
        JsonObject json = super.toJson();
        json.addProperty("type", "clip");
        json.addProperty("block", this.factor);
        return json;
    }

    @Override
    public Color getRingColor() {
        return new Color(255, 100, 0); // Orange-red
    }

    public BlockPos getBlockPos() {
        return new BlockPos(this.x, this.y, this.z);
    }
}