package me.fung.autop3.ring.types;

import com.google.gson.JsonObject;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.util.BlockPos;

public class JumpRing extends RingType {
    public JumpRing() {}

    public JumpRing(JsonObject json) {
        super(json);
    }

    @Override
    protected boolean execute() {
        Minecraft.getMinecraft().thePlayer.jump();
        return true;
    }

    @Override
    public JsonObject toJson() {
        JsonObject json = super.toJson();
        json.addProperty("type", "jump");
        return json;
    }

    @Override
    public Color getRingColor() {
        return new Color(0, 100, 255);
    }

    public BlockPos getBlockPos() {
        return new BlockPos(this.x, this.y, this.z);
    }
}