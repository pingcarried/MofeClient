package me.fung.autop3.ring.types;

import com.google.gson.JsonObject;
import java.awt.Color;
import net.minecraft.util.BlockPos;

public class TntRing extends RingType {
    public BlockPos pos;

    public TntRing(BlockPos pos) {
        this.pos = pos;
    }

    public TntRing(JsonObject json) {
        super(json);
        this.pos = new BlockPos(
                json.get("posX").getAsInt(),
                json.get("posY").getAsInt(),
                json.get("posZ").getAsInt()
        );
    }

    @Override
    protected boolean execute() {
        // Original TNT activation logic here
        return true;
    }

    @Override
    public JsonObject toJson() {
        JsonObject json = super.toJson();
        json.addProperty("type", "tnt");
        json.addProperty("posX", this.pos.getX());
        json.addProperty("posY", this.pos.getY());
        json.addProperty("posZ", this.pos.getZ());
        return json;
    }

    @Override
    public Color getRingColor() {
        return new Color(255, 100, 0);
    }
}