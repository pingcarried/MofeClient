package me.fung.autop3.ring.types;

import com.google.gson.JsonObject;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.util.BlockPos;

public class MotionRing extends RingType {
    public double yaw;

    public MotionRing(double yaw) {
        this.yaw = yaw;
    }

    public MotionRing(JsonObject json) {
        super(json);
        this.yaw = json.get("yaw").getAsDouble();
    }

    @Override
    protected boolean execute() {
        double rad = Math.toRadians(this.yaw);
        Minecraft.getMinecraft().thePlayer.motionX = -Math.sin(rad) * 0.5;
        Minecraft.getMinecraft().thePlayer.motionZ = Math.cos(rad) * 0.5;
        return true;
    }

    @Override
    public JsonObject toJson() {
        JsonObject json = super.toJson();
        json.addProperty("type", "motion");
        json.addProperty("yaw", this.yaw);
        return json;
    }

    @Override
    public Color getRingColor() {
        return new Color(200, 100, 0);
    }

    public BlockPos getBlockPos() {
        return new BlockPos(this.x, this.y, this.z);
    }
}