//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3.command;

import java.util.List;
import me.fung.autop3.features.BrushHandler;
import me.fung.autop3.utils.Utils;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommand;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.BlockPos;

public class BrushCommand extends CommandBase implements ICommand {
    public String func_71517_b() {
        return "brush";
    }

    public String func_71518_a(ICommandSender arg0) {
        return "/" + this.func_71517_b();
    }

    public int func_82362_a() {
        return 0;
    }

    public List<String> func_180525_a(ICommandSender sender, String[] args, BlockPos pos) {
        if (args.length == 1) {
            return func_71530_a(args, new String[]{"help", "setblock"});
        } else {
            if (args.length == 2) {
                String arg1 = args[0].toLowerCase();
                if (arg1.equals("setblock")) {
                    return func_175762_a(args, Block.field_149771_c.func_148742_b());
                }
            }

            return null;
        }
    }

    public void func_71515_b(ICommandSender sender, String[] args) {
        if (args.length == 0) {
            BrushHandler.editMode = !BrushHandler.editMode;
            if (BrushHandler.editMode) {
                Utils.addChatMessage("Edit Mode §aEnabled");
            } else {
                BrushHandler.saveConfig();
                Utils.addChatMessage("Edit Mode §cDisabled");
            }

        } else {
            EntityPlayerSP player = Minecraft.func_71410_x().field_71439_g;
            switch (args[0].toLowerCase()) {
                case "help":
                    Utils.addChatMessage("");
                case "setblock":
                    break;
                default:
                    Utils.addChatMessage("Usage: /brush <help/setblock>");
            }

        }
    }
}
