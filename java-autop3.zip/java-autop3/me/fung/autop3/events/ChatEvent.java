//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3.events;

import net.minecraft.util.IChatComponent;
import net.minecraftforge.fml.common.eventhandler.Cancelable;
import net.minecraftforge.fml.common.eventhandler.Event;

@Cancelable
public class ChatEvent extends Event {
    public String unformatted;
    public IChatComponent message;

    public ChatEvent(String unformatted, IChatComponent message) {
        this.unformatted = unformatted;
        this.message = message;
    }

    public static class PartyChat extends Event {
        public String message;
        public String sender;

        public PartyChat(String message, String sender) {
            this.message = message;
            this.sender = sender;
        }
    }

    public static class PartyCommand extends Event {
        public String command;
        public String sender;
        public String[] args;

        public PartyCommand(String command, String sender, String[] args) {
            this.command = command;
            this.sender = sender;
            this.args = args;
        }
    }

    @Cancelable
    public static class PrivateChatCommand extends Event {
        public String command;
        public String sender;
        public String[] args;

        public PrivateChatCommand(String command, String sender, String[] args) {
            this.command = command;
            this.sender = sender;
            this.args = args;
        }
    }
}
