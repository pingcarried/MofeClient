//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3.events;

import net.minecraft.client.gui.inventory.GuiChest;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.eventhandler.Cancelable;
import net.minecraftforge.fml.common.eventhandler.Event;

@Cancelable
public class SlotClickedEvent extends Event {
    public final Slot slot;
    public final ItemStack item;
    public final int key;
    public final int mouse;

    public SlotClickedEvent(Slot slot, ItemStack item, int key, int mouse) {
        this.slot = slot;
        this.item = item;
        this.key = key;
        this.mouse = mouse;
    }

    public static class Inventory extends SlotClickedEvent {
        public Inventory(Slot slot, ItemStack item, int key, int mouse) {
            super(slot, item, key, mouse);
        }
    }

    public static class Chest extends SlotClickedEvent {
        public final GuiChest chest;
        public final IInventory inventory;
        public final String inventoryName;

        public Chest(GuiChest chest, IInventory inventory, String inventoryName, Slot slot, ItemStack item, int key, int mouse) {
            super(slot, item, key, mouse);
            this.chest = chest;
            this.inventory = inventory;
            this.inventoryName = inventoryName;
        }
    }
}
