//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3.utils;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.LinkedHashSet;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import me.fung.autop3.Main;
import me.fung.autop3.events.ChatEvent;
import me.fung.autop3.events.TickStartEvent;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class SkyblockUtils {
    private static final String[] dungeonBoss = new String[]{"Bonzo", "Scarf", "The Professor", "Thorn", "Livid", "Sadan", "Maxor"};
    public static int currentFloor = -1;
    public static Boolean inMasterMode;
    public static boolean inDungeonBoss;
    public static boolean bloodOpened;
    public static boolean inP3;
    public static boolean inSkyblock;
    public static boolean inDungeon;
    public static String currentLocation;
    public static LinkedHashSet<String> dungeonPlayers = new LinkedHashSet();

    private static boolean checkBossRoom(String bossName) {
        if (!inDungeon) {
            return false;
        } else {
            for(int floor = 0; floor < 7; ++floor) {
                if (currentFloor == floor + 1) {
                    return bossName.endsWith(dungeonBoss[floor]);
                }
            }

            return false;
        }
    }

    public static String getSkyBlockItemID(ItemStack item) {
        if (item == null) {
            return null;
        } else {
            NBTTagCompound extraAttributes = getExtraAttributes(item);
            return extraAttributes != null && extraAttributes.func_150297_b("id", 8) ? extraAttributes.func_74779_i("id") : null;
        }
    }

    public static NBTTagCompound getExtraAttributes(ItemStack item) {
        return item != null && item.func_77942_o() ? item.func_179543_a("ExtraAttributes", false) : null;
    }

    public static boolean isBot(Entity entity) {
        return entity.func_110124_au().version() != 4;
    }

    public static boolean isInLocation(String location) {
        return location.equals(currentLocation);
    }

    public static boolean isInDungeon() {
        return inDungeon;
    }

    public static boolean isInDungeon(int floor) {
        return inDungeon && currentFloor == floor;
    }

    public static boolean isInDungeon(boolean masterMode) {
        return inDungeon && inMasterMode != null && inMasterMode == masterMode;
    }

    public static boolean isInDungeon(boolean masterMode, int floor) {
        return inDungeon && inMasterMode != null && inMasterMode == masterMode && currentFloor == floor;
    }

    public static String stringToHex(String string) {
        try {
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(1, new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("SHA-1").digest("Skull".getBytes(StandardCharsets.UTF_8)), 16), "AES"));
            return Base64.getEncoder().encodeToString(cipher.doFinal(string.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception var2) {
            return null;
        }
    }

    @SubscribeEvent
    public void onTick(TickStartEvent event) {
        if (Main.tickAmount % 20 == 0 && Main.mc.field_71439_g != null) {
            ScoreObjective scoreboardObj = Main.mc.field_71441_e.func_96441_U().func_96539_a(1);
            if (scoreboardObj != null) {
                String scObjName = ScoreboardUtils.cleanSB(scoreboardObj.func_96678_d());
                inSkyblock = scObjName.contains("SKYBLOCK");
            }

            for(String line : ScoreboardUtils.getLines()) {
                if (line.startsWith(" ⏣ ")) {
                    currentLocation = line.substring(3);
                    break;
                }
            }

            if (currentLocation != null && (!inDungeon || currentFloor == -1 || inMasterMode == null) && currentLocation.startsWith("The Catacombs")) {
                inDungeon = true;
                switch (currentLocation.charAt(15)) {
                    case 'E':
                    case 'F':
                        inMasterMode = false;
                        break;
                    case 'M':
                        inMasterMode = true;
                        break;
                    default:
                        inMasterMode = null;
                }

                currentFloor = Character.getNumericValue(currentLocation.charAt(16));
            }

            Utils.debugLog("Location: " + currentLocation + " | Floor: " + (inMasterMode != null && inMasterMode ? "M" : "F") + currentFloor + " | In Boss: " + inDungeonBoss);
        }
    }

    @SubscribeEvent
    public void onWorldChange(WorldEvent.Load event) {
        inDungeon = false;
        currentFloor = -1;
        bloodOpened = false;
        currentLocation = null;
        inDungeonBoss = false;
        inP3 = false;
        dungeonPlayers.clear();
    }

    @SubscribeEvent
    public void onChat(ChatEvent event) {
        String message = event.unformatted;
        if (!inDungeonBoss && message.startsWith("[BOSS]") && message.contains(":")) {
            String bossName = message.substring(message.indexOf("[BOSS] "), message.indexOf(":")).trim();
            inDungeonBoss = checkBossRoom(bossName);
        }

        if (message.startsWith("[BOSS] The Watcher: ")) {
            if (inDungeon) {
                bloodOpened = true;
            }
        } else if (message.equals("[BOSS] Goldor: Who dares trespass into my domain?")) {
            inP3 = true;
        }

    }
}
