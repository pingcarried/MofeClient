//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3.utils;

import com.google.gson.JsonObject;
import java.awt.Color;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.StringJoiner;
import me.fung.autop3.ConfigGui;
import me.fung.autop3.Main;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.event.HoverEvent;
import net.minecraft.event.HoverEvent.Action;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.ChatStyle;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.Phase;

public class Utils {
    private static final ArrayList<TickTask> tasks = new ArrayList();
    public static boolean debugMode;
    public static ArrayList<String> messageQueue = new ArrayList();

    public static String[] subStringArray(String[] array, int startIndex) {
        return (String[])Arrays.copyOfRange(array, startIndex, array.length - startIndex);
    }

    public static String[] subStringArray(String[] array, int startIndex, int endIndex) {
        return (String[])Arrays.copyOfRange(array, startIndex, endIndex);
    }

    public static <T> String arrayJoin(CharSequence delimiter, Iterable<T> iterable) {
        StringJoiner joiner = new StringJoiner(delimiter);

        for(T object : iterable) {
            joiner.add(object.toString());
        }

        return joiner.toString();
    }

    public static boolean isInGame() {
        return Minecraft.func_71410_x().field_71439_g != null && Minecraft.func_71410_x().field_71441_e != null;
    }

    public static String arrayToString(String[] array) {
        if (array.length == 0) {
            return "";
        } else {
            StringBuilder builder = new StringBuilder(array[0]);

            for(int i = 1; i < array.length; ++i) {
                builder.append(" ").append(array[i]);
            }

            return builder.toString();
        }
    }

    public static void addChatMessage(String message) {
        if (Main.mc.field_71439_g != null) {
            Main.mc.field_71439_g.func_145747_a(new ChatComponentText(ConfigGui.INSTANCE.prefix + message));
        }

    }

    public static void debugLog(String message) {
        if (Main.mc.field_71439_g != null && debugMode) {
            Main.mc.field_71439_g.func_145747_a(new ChatComponentText(ConfigGui.INSTANCE.prefix + message));
        }

    }

    public static ChatComponentText createHoverComponent(String text, String hovered) {
        ChatComponentText hover = new ChatComponentText(text);
        ChatStyle chatStyle = new ChatStyle();
        chatStyle.func_150209_a(new HoverEvent(Action.SHOW_TEXT, new ChatComponentText(hovered)));
        hover.func_150255_a(chatStyle);
        return hover;
    }

    public static boolean equalsOneOf(Object obj, Object... arg) {
        for(Object o : arg) {
            if (o.equals(obj)) {
                return true;
            }
        }

        return false;
    }

    public static String colorToHex(Color color) {
        return String.format("%02x%02x%02x%02x", color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
    }

    public static Color hexToColor(String hex) {
        return null;
    }

    public static String translateAlternateColorCodes(String textToTranslate) {
        char[] b = textToTranslate.toCharArray();

        for(int i = 0; i < b.length - 1; ++i) {
            if (b[i] == '&' && "0123456789AaBbCcDdEeFfKkLlMmNnOoRrZz".indexOf(b[i + 1]) > -1) {
                b[i] = 167;
                b[i + 1] = Character.toLowerCase(b[i + 1]);
            }
        }

        return new String(b);
    }

    public static void sendMessage(String message) {
        messageQueue.add(message);
    }

    public static void sendMessageWithDelay(String message) {
        messageQueue.add(message);
    }

    public static void addChatMessageWithoutPrefix(String message) {
        Main.mc.field_71439_g.func_145747_a(new ChatComponentText(message));
    }

    public static void setKeyBindState(KeyBinding keybind, boolean state) {
        KeyBinding.func_74510_a(keybind.func_151463_i(), state);
    }

    public static void writeClipBoard(String str) {
        StringSelection selection = new StringSelection(str);
        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        clipboard.setContents(selection, selection);
    }

    public static String getClipBoard() {
        try {
            return Toolkit.getDefaultToolkit().getSystemClipboard().getData(DataFlavor.stringFlavor).toString();
        } catch (Exception var1) {
            return null;
        }
    }

    public static List<String> getItemLore(ItemStack itemStack) {
        if (itemStack == null) {
            return null;
        } else {
            int NBT_INTEGER = 3;
            int NBT_STRING = 8;
            int NBT_LIST = 9;
            int NBT_COMPOUND = 10;
            if (itemStack.func_77942_o() && itemStack.func_77978_p().func_150297_b("display", 10)) {
                NBTTagCompound display = itemStack.func_77978_p().func_74775_l("display");
                if (display.func_150297_b("Lore", 9)) {
                    NBTTagList lore = display.func_150295_c("Lore", 8);
                    List<String> loreAsList = new ArrayList();

                    for(int lineNumber = 0; lineNumber < lore.func_74745_c(); ++lineNumber) {
                        loreAsList.add(lore.func_150307_f(lineNumber));
                    }

                    return Collections.unmodifiableList(loreAsList);
                }
            }

            return Collections.emptyList();
        }
    }

    public static String getTimeBetween(double timeOne, double timeTwo) {
        return getTimeBetween(Math.floor(timeTwo - timeOne));
    }

    public static String getTimeBetween(long timeOne, long timeTwo) {
        return getTimeBetween(Math.floor((double)timeTwo / (double)1000.0F - (double)timeOne / (double)1000.0F));
    }

    public static JsonObject getObjectFromPath(JsonObject obj, String path) {
        if (obj == null) {
            return null;
        } else {
            String[] split = path.split("\\.");
            JsonObject newObj = obj;

            for(String id : split) {
                if (!newObj.has(id)) {
                    return null;
                }

                newObj = newObj.getAsJsonObject(id);
            }

            return newObj;
        }
    }

    public static String getTimeBetween(double second) {
        String timeFormatted;
        if (second > (double)86400.0F) {
            int days = (int)(second / (double)86400.0F);
            int hours = (int)(second % (double)86400.0F / (double)3600.0F);
            timeFormatted = days + (hours < 10 ? "d0" : "d") + hours + "h";
        } else if (second > (double)3600.0F) {
            int hours = (int)(second / (double)3600.0F);
            int minutes = (int)(second % (double)3600.0F / (double)60.0F);
            timeFormatted = hours + (minutes < 10 ? "h0" : "h") + minutes + "m";
        } else if (second > (double)60.0F) {
            int minutes = (int)(second / (double)60.0F);
            int seconds = (int)(second % (double)60.0F);
            timeFormatted = minutes + (seconds < 10 ? "m0" : "m") + seconds + "s";
        } else {
            int seconds = (int)(second % (double)60.0F);
            timeFormatted = seconds + "s";
        }

        return timeFormatted;
    }

    public static String removeRank(String message) {
        return message.replaceAll("\\[\\S+\\] ?", "");
    }

    public static boolean isInArea(double areaX1, double areaZ1, double areaX2, double areaZ2, double x, double z) {
        double minX = Math.min(areaX1, areaX2);
        double minZ = Math.min(areaZ1, areaZ2);
        double maxX = Math.max(areaX1, areaX2);
        double maxZ = Math.max(areaZ1, areaZ2);
        return x >= minX && x <= maxX && z >= minZ && z <= maxZ;
    }

    public static boolean isInArea(double areaX1, double areaY1, double areaZ1, double areaX2, double areaY2, double areaZ2, double x, double y, double z) {
        double minX = Math.min(areaX1, areaX2);
        double minY = Math.min(areaY1, areaY2);
        double minZ = Math.min(areaZ1, areaZ2);
        double maxX = Math.max(areaX1, areaX2);
        double maxY = Math.max(areaY1, areaY2);
        double maxZ = Math.max(areaZ1, areaZ2);
        return x >= minX && x <= maxX && y >= minY && y <= maxY && z >= minZ && z <= maxZ;
    }

    public static boolean isInArea(double areaX1, double areaY1, double areaZ1, double areaX2, double areaY2, double areaZ2, Entity entity) {
        return isInArea(areaX1, areaY1, areaZ1, areaX2, areaY2, areaZ2, entity.field_70165_t, entity.field_70163_u, entity.field_70161_v);
    }

    public static void scheduleTask(int delayTick, Task task) {
        tasks.add(new TickTask(delayTick, task, false));
    }

    public static void scheduleTask(int delayTick, Task task, boolean isTickEnd) {
        tasks.add(new TickTask(delayTick, task, isTickEnd));
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        tasks.removeIf((task) -> {
            if (task.isTickEnd != (event.phase == Phase.END)) {
                return false;
            } else if (task.delayTick > 0) {
                task.delayTick--;
                return false;
            } else {
                task.task.run();
                return true;
            }
        });
    }

    public static class TickTask {
        private final Task task;
        private int delayTick;
        private final boolean isTickEnd;

        public TickTask(int delayTick, Task task, boolean isTickEnd) {
            this.delayTick = delayTick;
            this.task = task;
            this.isTickEnd = isTickEnd;
        }
    }

    public interface Task {
        void run();
    }
}
