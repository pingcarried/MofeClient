//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package me.fung.autop3.utils;

import net.minecraft.util.Vec3;

public class MathUtils {
    public static float getDelta(float number1, float number2) {
        float a = number1 - number2;
        return noNegative(a);
    }

    public static int getDelta(int number1, int number2) {
        int a = number1 - number2;
        return noNegative(a);
    }

    public static String formatFloat(double number) {
        return String.format("%.1f", number).replaceAll("\\.*0*$", "");
    }

    public static String toBeFixed(double number, int fix) {
        String format = "%." + fix + "f";
        return String.format(format, number).replaceAll("\\.*0*$", "");
    }

    public static int noNegative(int number) {
        return number < 0 ? -number : number;
    }

    public static float noNegative(float number) {
        return number < 0.0F ? -number : number;
    }

    public static int randomNumber(int min, int max) {
        return (int)(Math.random() * (double)(max - min + 1) + (double)min);
    }

    public static float randomNumber(float min, float max) {
        return (float)((double)min + Math.random() * (double)(max - min));
    }

    public static double randomNumber(double min, double max) {
        return min + Math.random() * (max - min);
    }

    public static class Box {
        public double minX;
        public double minY;
        public double minZ;
        public double maxX;
        public double maxY;
        public double maxZ;

        public Box(double x1, double y1, double z1, double x2, double y2, double z2) {
            this.minX = Math.min(x1, x2);
            this.minY = Math.min(y1, y2);
            this.minZ = Math.min(z1, z2);
            this.maxX = Math.max(x1, x2);
            this.maxY = Math.max(y1, y2);
            this.maxZ = Math.max(z1, z2);
        }

        private boolean contains(double x, double y, double z) {
            return x >= this.minX && x <= this.maxX && y >= this.minY && y <= this.maxY && z >= this.minZ && z <= this.maxZ;
        }

        public boolean intersects(Vec3 startVec, Vec3 endVec) {
            return this.intersects(startVec.field_72450_a, startVec.field_72448_b, startVec.field_72449_c, endVec.field_72450_a, endVec.field_72448_b, endVec.field_72449_c);
        }

        public boolean intersects(double startX, double startY, double startZ, double endX, double endY, double endZ) {
            double pMinX = Math.min(startX, endX);
            double pMinY = Math.min(startY, endY);
            double pMinZ = Math.min(startZ, endZ);
            double pMaxX = Math.max(startX, endX);
            double pMaxY = Math.max(startY, endY);
            double pMaxZ = Math.max(startZ, endZ);
            if (this.minX <= pMaxX && this.maxX >= pMinX && this.minY <= pMaxY && this.maxY >= pMinY && this.minZ <= pMaxZ && this.maxZ >= pMinZ) {
                double[] dir = new double[]{endX - startX, endY - startY, endZ - startZ};
                double tMin = (this.minX - startX) / dir[0];
                double tMax = (this.maxX - startX) / dir[0];
                if (tMin > tMax) {
                    double temp = tMin;
                    tMin = tMax;
                    tMax = temp;
                }

                double tyMin = (this.minY - startY) / dir[1];
                double tyMax = (this.maxY - startY) / dir[1];
                if (tyMin > tyMax) {
                    double temp = tyMin;
                    tyMin = tyMax;
                    tyMax = temp;
                }

                if (!(tMin > tyMax) && !(tyMin > tMax)) {
                    if (tyMin > tMin) {
                        tMin = tyMin;
                    }

                    if (tyMax < tMax) {
                        tMax = tyMax;
                    }

                    double tzMin = (this.minZ - startZ) / dir[2];
                    double tzMax = (this.maxZ - startZ) / dir[2];
                    if (tzMin > tzMax) {
                        double temp = tzMin;
                        tzMin = tzMax;
                        tzMax = temp;
                    }

                    return !(tMin > tzMax) && !(tzMin > tMax);
                } else {
                    return false;
                }
            } else {
                return false;
            }
        }
    }
}
